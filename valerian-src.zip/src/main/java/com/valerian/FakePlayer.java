package com.valerian;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.MathHelper;

/**
 * A training dummy that looks like you. It only exists on your screen: hits are counted here,
 * nothing is sent to the server as damage.
 */
public final class FakePlayer {
	private static OtherClientPlayerEntity dummy = null;
	private static ClientWorld dummyWorld = null;
	private static float hp = 20f;
	private static int hitCooldown = 0;
	private static int deathTicks = -1;
	private static boolean dead = false;
	private static int respawnTimer = 0;
	private static double kbX = 0.0;
	private static double kbZ = 0.0;
	private static boolean lastAttack = false;

	private FakePlayer() {}

	public static boolean isFake(Entity e) {
		return e != null && e == dummy;
	}

	private static void remove() {
		if (dummy != null) {
			dummy.discard();
			dummy = null;
		}
		dummyWorld = null;
		deathTicks = -1;
		kbX = 0.0;
		kbZ = 0.0;
	}

	public static void tick(MinecraftClient mc) {
		if (!ModuleManager.isEnabled("FakePlayer") || mc.player == null || mc.world == null) {
			remove();
			dead = false;
			respawnTimer = 0;
			lastAttack = false;
			return;
		}
		if (dummy != null && (dummyWorld != mc.world || (dummy.isRemoved() && deathTicks < 0))) {
			remove();
		}
		if (dummy == null) {
			if (dead) {
				if (!Config.get("fake.respawn", "On").equals("Off") && respawnTimer-- <= 0) {
					dead = false;
					spawn(mc);
				}
				return;
			}
			spawn(mc);
			if (dummy == null) return;
		}

		if (deathTicks >= 0) {
			deathTicks++;
			if (deathTicks >= 24) {
				dummy.discard();
				dummy = null;
				deathTicks = -1;
				dead = true;
				respawnTimer = 60;
			}
			return;
		}

		// keep facing you
		ClientPlayerEntity p = mc.player;
		float face = (float) Math.toDegrees(Math.atan2(-(p.getX() - dummy.getX()), p.getZ() - dummy.getZ()));
		float yaw = dummy.getYaw() + MathHelper.wrapDegrees(face - dummy.getYaw()) * 0.25f;
		dummy.setYaw(yaw);
		dummy.setBodyYaw(yaw);
		dummy.setHeadYaw(yaw);
		dummy.setPitch(0f);
		dummy.setOnGround(true);

		// knockback slides the dummy away
		if (Math.abs(kbX) > 0.002 || Math.abs(kbZ) > 0.002) {
			dummy.setPosition(dummy.getX() + kbX, dummy.getY(), dummy.getZ() + kbZ);
			kbX *= 0.6;
			kbZ *= 0.6;
		}

		// hitting it
		boolean attack = mc.options.attackKey.isPressed();
		if (attack && !lastAttack && mc.currentScreen == null && mc.targetedEntity == dummy && hitCooldown <= 0) {
			hit(mc);
		}
		lastAttack = attack;
		if (hitCooldown > 0) hitCooldown--;
	}

	private static float damageFor(ClientPlayerEntity p) {
		String d = Config.get("fake.damage", "Auto");
		float base;
		if (d.equals("Auto")) {
			if (p.getMainHandStack().isIn(ItemTags.SWORDS)) {
				base = 7f;
			} else if (p.getMainHandStack().isIn(ItemTags.AXES)) {
				base = 9f;
			} else {
				base = 1f;
			}
		} else {
			try {
				base = Float.parseFloat(d);
			} catch (NumberFormatException e) {
				base = 4f;
			}
		}
		boolean crit = p.fallDistance > 0f && !p.isOnGround();
		return crit ? base * 1.5f : base;
	}

	private static void hit(MinecraftClient mc) {
		ClientPlayerEntity p = mc.player;
		hitCooldown = 10;
		hp -= damageFor(p);

		double dx = dummy.getX() - p.getX();
		double dz = dummy.getZ() - p.getZ();
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len > 0.001) {
			kbX = dx / len * 0.32;
			kbZ = dz / len * 0.32;
		}

		if (hp <= 0f) {
			if (!Config.get("fake.immortal", "On").equals("Off")) {
				hp = 20f;
				dummy.setHealth(20f);
				dummy.handleStatus((byte) 2);
			} else {
				hp = 0f;
				dummy.handleStatus((byte) 3);
				deathTicks = 0;
			}
		} else {
			dummy.setHealth(hp);
			dummy.handleStatus((byte) 2);
		}
	}

	private static void spawn(MinecraftClient mc) {
		ClientPlayerEntity p = mc.player;
		ClientWorld world = mc.world;
		GameProfile profile = new GameProfile(UUID.randomUUID(), "Dummy");
		OtherClientPlayerEntity e = new OtherClientPlayerEntity(world, profile);
		double yaw = Math.toRadians(p.getYaw());
		double x = p.getX() - Math.sin(yaw) * 2.5;
		double z = p.getZ() + Math.cos(yaw) * 2.5;
		e.setId(-888001);
		e.setNoGravity(true);
		e.setPosition(x, p.getY(), z);
		float face = (float) Math.toDegrees(Math.atan2(-(p.getX() - x), p.getZ() - z));
		e.setYaw(face);
		e.setBodyYaw(face);
		e.setHeadYaw(face);
		EquipmentSlot[] slots = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
			EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
		for (EquipmentSlot s : slots) {
			e.equipStack(s, p.getEquippedStack(s).copy());
		}
		e.setHealth(20f);
		world.addEntity(e);
		dummy = e;
		dummyWorld = world;
		hp = 20f;
		hitCooldown = 0;
		deathTicks = -1;
		kbX = 0.0;
		kbZ = 0.0;
	}
}
