package com.valerian.mixin;

import com.valerian.CustomWeapons;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ItemModelManager.class)
public abstract class ItemModelManagerMixin {
	@ModifyVariable(
		method = "update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/world/World;Lnet/minecraft/util/HeldItemContext;I)V",
		at = @At("HEAD"),
		argsOnly = true
	)
	private ItemStack valerian$customWeapon(ItemStack stack) {
		return CustomWeapons.replace(stack);
	}
}
