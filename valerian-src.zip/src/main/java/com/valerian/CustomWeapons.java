package com.valerian;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;

/** Swaps what swords, axes and bows look like. The real items and their stats are unchanged. */
public final class CustomWeapons {
	private static final Map<String, ItemStack> CACHE = new HashMap<>();

	private CustomWeapons() {}

	private static String modelFor(String choice) {
		switch (choice) {
			case "Dagger":
				return "dagger";
			case "Curved Blade":
				return "curved_blade";
			case "Battle Axe":
				return "battle_axe";
			case "Frost Axe":
				return "frost_axe";
			case "Rifle":
				return "rifle";
			default:
				return null;
		}
	}

	public static ItemStack replace(ItemStack stack) {
		if (stack == null || stack.isEmpty() || !ModuleManager.isEnabled("CustomWeapons")) return stack;
		String id = null;
		if (stack.isIn(ItemTags.SWORDS)) {
			id = modelFor(Config.get("weapons.sword", "Dagger"));
		} else if (stack.isIn(ItemTags.AXES)) {
			id = modelFor(Config.get("weapons.axe", "Battle Axe"));
		} else if (stack.isOf(Items.BOW)) {
			id = modelFor(Config.get("weapons.bow", "Rifle"));
		}
		if (id == null) return stack;
		ItemStack cached = CACHE.get(id);
		if (cached == null) {
			cached = new ItemStack(Items.STICK);
			cached.set(DataComponentTypes.ITEM_MODEL, Identifier.of("valerian", id));
			CACHE.put(id, cached);
		}
		return cached;
	}
}
