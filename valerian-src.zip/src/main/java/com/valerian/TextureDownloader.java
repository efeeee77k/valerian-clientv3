package com.valerian;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.loader.api.FabricLoader;

/** Searches resource packs on Modrinth and saves them into the resourcepacks folder. */
public final class TextureDownloader {
	public record Pack(String id, String title, int downloads) {}

	private static final String GAME_VERSION = "1.21.11";
	private static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();

	private static volatile List<Pack> results = new ArrayList<>();
	private static volatile String status = "Search for a texture pack and press Download";
	private static volatile int version = 0;
	private static volatile boolean loadedOnce = false;

	private TextureDownloader() {}

	public static List<Pack> results() {
		return results;
	}

	public static String status() {
		return status;
	}

	public static int version() {
		return version;
	}

	public static boolean loadedOnce() {
		return loadedOnce;
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	private static HttpRequest request(String url) {
		return HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "ValerianClient/1.0 (resource pack browser)").build();
	}

	public static void search(String query, int page) {
		loadedOnce = true;
		status = "Searching...";
		version++;
		CompletableFuture.runAsync(() -> {
			try {
				String facets = "[[\"project_type:resourcepack\"],[\"versions:" + GAME_VERSION + "\"]]";
				String url = "https://api.modrinth.com/v2/search?query=" + enc(query) + "&facets=" + enc(facets)
					+ "&limit=6&offset=" + (page * 6) + "&index=downloads";
				HttpResponse<String> res = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString());
				if (res.statusCode() != 200) {
					status = "Search failed (HTTP " + res.statusCode() + ")";
					version++;
					return;
				}
				JsonArray hits = JsonParser.parseString(res.body()).getAsJsonObject().getAsJsonArray("hits");
				List<Pack> list = new ArrayList<>();
				for (JsonElement e : hits) {
					JsonObject o = e.getAsJsonObject();
					list.add(new Pack(o.get("project_id").getAsString(), o.get("title").getAsString(), o.get("downloads").getAsInt()));
				}
				results = list;
				status = list.isEmpty() ? "Nothing found" : "Pick a pack to download";
			} catch (Exception e) {
				ValerianClient.LOGGER.warn("Texture search failed", e);
				status = "Search failed, check your internet";
			}
			version++;
		});
	}

	private static String cleanName(String name) {
		String n = name.replaceAll("[^A-Za-z0-9._ -]", "_");
		return n.toLowerCase().endsWith(".zip") ? n : n + ".zip";
	}

	public static void download(Pack pack) {
		status = "Downloading " + pack.title() + "...";
		version++;
		CompletableFuture.runAsync(() -> {
			try {
				String url = "https://api.modrinth.com/v2/project/" + pack.id() + "/version?game_versions=" + enc("[\"" + GAME_VERSION + "\"]");
				HttpResponse<String> res = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString());
				if (res.statusCode() != 200) {
					status = "Download failed (HTTP " + res.statusCode() + ")";
					version++;
					return;
				}
				JsonArray versions = JsonParser.parseString(res.body()).getAsJsonArray();
				if (versions.isEmpty()) {
					status = "No file for " + GAME_VERSION;
					version++;
					return;
				}
				JsonArray files = versions.get(0).getAsJsonObject().getAsJsonArray("files");
				JsonObject file = files.get(0).getAsJsonObject();
				for (JsonElement f : files) {
					JsonObject o = f.getAsJsonObject();
					if (o.has("primary") && o.get("primary").getAsBoolean()) file = o;
				}
				String fileUrl = file.get("url").getAsString();
				String fileName = cleanName(file.get("filename").getAsString());
				HttpResponse<byte[]> data = HTTP.send(request(fileUrl), HttpResponse.BodyHandlers.ofByteArray());
				if (data.statusCode() != 200) {
					status = "Download failed (HTTP " + data.statusCode() + ")";
					version++;
					return;
				}
				Path dir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
				Files.createDirectories(dir);
				Files.write(dir.resolve(fileName), data.body());
				status = "Saved " + fileName + ". Turn it on in Options > Resource Packs";
			} catch (Exception e) {
				ValerianClient.LOGGER.warn("Texture download failed", e);
				status = "Download failed";
			}
			version++;
		});
	}
}
