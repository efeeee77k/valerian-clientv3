package com.valerian;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.texture.NativeImage;

/** Searches resource packs on Modrinth, loads preview thumbnails and saves packs into resourcepacks. */
public final class TextureDownloader {
	public record Pack(String id, String title, String author, String desc, int downloads, int follows) {}

	public static final int THUMB_W = 64;
	public static final int THUMB_H = 36;
	private static final int[] EMPTY = new int[0];

	private static final String GAME_VERSION = "1.21.11";
	private static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();

	private static final Map<String, int[]> THUMBS = new ConcurrentHashMap<>();
	private static final Set<String> LOADING = ConcurrentHashMap.newKeySet();

	private static volatile List<Pack> results = new ArrayList<>();
	private static volatile String status = "Search for a texture pack and press Get";
	private static volatile int version = 0;
	private static volatile boolean loadedOnce = false;

	private TextureDownloader() {}

	public static List<Pack> results() {
		return results;
	}

	public static String status() {
		return status;
	}

	public static int version() {
		return version;
	}

	public static boolean loadedOnce() {
		return loadedOnce;
	}

	/** Returns the thumbnail pixels (THUMB_W * THUMB_H RGB values), an empty array if none, or null while loading. */
	public static int[] thumb(String id) {
		return THUMBS.get(id);
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	private static HttpRequest request(String url) {
		return HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "ValerianClient/1.0 (resource pack browser)").build();
	}

	private static String str(JsonObject o, String key) {
		if (!o.has(key) || o.get(key).isJsonNull()) return "";
		return o.get(key).getAsString();
	}

	private static int num(JsonObject o, String key) {
		if (!o.has(key) || o.get(key).isJsonNull()) return 0;
		return o.get(key).getAsInt();
	}

	public static void search(String query, int page, int perPage) {
		loadedOnce = true;
		status = "Searching...";
		version++;
		CompletableFuture.runAsync(() -> {
			try {
				String facets = "[[\"project_type:resourcepack\"],[\"versions:" + GAME_VERSION + "\"]]";
				String url = "https://api.modrinth.com/v2/search?query=" + enc(query) + "&facets=" + enc(facets)
					+ "&limit=" + perPage + "&offset=" + (page * perPage) + "&index=downloads";
				HttpResponse<String> res = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString());
				if (res.statusCode() != 200) {
					status = "Search failed (HTTP " + res.statusCode() + ")";
					version++;
					return;
				}
				JsonArray hits = JsonParser.parseString(res.body()).getAsJsonObject().getAsJsonArray("hits");
				List<Pack> list = new ArrayList<>();
				for (JsonElement e : hits) {
					JsonObject o = e.getAsJsonObject();
					list.add(new Pack(str(o, "project_id"), str(o, "title"), str(o, "author"), str(o, "description"),
						num(o, "downloads"), num(o, "follows")));
				}
				results = list;
				status = list.isEmpty() ? "Nothing found" : "Pick a pack and press Get";
				version++;
				for (Pack p : list) loadThumb(p.id());
			} catch (Exception e) {
				ValerianClient.LOGGER.warn("Texture search failed", e);
				status = "Search failed, check your internet";
				version++;
			}
		});
	}

	private static void loadThumb(String id) {
		if (THUMBS.containsKey(id) || !LOADING.add(id)) return;
		try {
			HttpResponse<String> res = HTTP.send(request("https://api.modrinth.com/v2/project/" + id), HttpResponse.BodyHandlers.ofString());
			String imgUrl = null;
			if (res.statusCode() == 200) {
				JsonObject proj = JsonParser.parseString(res.body()).getAsJsonObject();
				if (proj.has("gallery") && proj.get("gallery").isJsonArray() && proj.getAsJsonArray("gallery").size() > 0) {
					JsonArray gallery = proj.getAsJsonArray("gallery");
					JsonObject chosen = gallery.get(0).getAsJsonObject();
					for (JsonElement g : gallery) {
						JsonObject o = g.getAsJsonObject();
						if (o.has("featured") && o.get("featured").getAsBoolean()) chosen = o;
					}
					imgUrl = str(chosen, "raw_url");
					if (imgUrl.isEmpty()) imgUrl = str(chosen, "url");
				}
			}
			if (imgUrl == null || imgUrl.isEmpty()) {
				THUMBS.put(id, EMPTY);
				return;
			}
			HttpResponse<byte[]> img = HTTP.send(request(imgUrl), HttpResponse.BodyHandlers.ofByteArray());
			if (img.statusCode() == 200 && img.body().length < 12_000_000) {
				THUMBS.put(id, makeThumb(img.body()));
			} else {
				THUMBS.put(id, EMPTY);
			}
		} catch (Exception e) {
			THUMBS.put(id, EMPTY);
		} finally {
			LOADING.remove(id);
		}
	}

	private static int[] makeThumb(byte[] bytes) {
		try (NativeImage img = NativeImage.read(new ByteArrayInputStream(bytes))) {
			int w = img.getWidth();
			int h = img.getHeight();
			int[] out = new int[THUMB_W * THUMB_H];
			for (int ty = 0; ty < THUMB_H; ty++) {
				for (int tx = 0; tx < THUMB_W; tx++) {
					int r = 0;
					int g = 0;
					int b = 0;
					int n = 0;
					for (int oy = 0; oy < 3; oy++) {
						for (int ox = 0; ox < 3; ox++) {
							int sx = Math.min(w - 1, (int) ((tx + (ox + 0.5) / 3.0) * w / THUMB_W));
							int sy = Math.min(h - 1, (int) ((ty + (oy + 0.5) / 3.0) * h / THUMB_H));
							int argb = img.getColorArgb(sx, sy);
							int a = (argb >>> 24) & 255;
							if (a < 40) {
								argb = 0x15151B;
							}
							r += (argb >> 16) & 255;
							g += (argb >> 8) & 255;
							b += argb & 255;
							n++;
						}
					}
					int rr = (r / n) & 0xF8;
					int gg = (g / n) & 0xF8;
					int bb = (b / n) & 0xF8;
					out[ty * THUMB_W + tx] = (rr << 16) | (gg << 8) | bb;
				}
			}
			return out;
		} catch (Exception e) {
			return EMPTY;
		}
	}

	private static String cleanName(String name) {
		String n = name.replaceAll("[^A-Za-z0-9._ -]", "_");
		return n.toLowerCase().endsWith(".zip") ? n : n + ".zip";
	}

	public static void download(Pack pack) {
		status = "Downloading " + pack.title() + "...";
		version++;
		CompletableFuture.runAsync(() -> {
			try {
				String url = "https://api.modrinth.com/v2/project/" + pack.id() + "/version?game_versions=" + enc("[\"" + GAME_VERSION + "\"]");
				HttpResponse<String> res = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString());
				if (res.statusCode() != 200) {
					status = "Download failed (HTTP " + res.statusCode() + ")";
					version++;
					return;
				}
				JsonArray versions = JsonParser.parseString(res.body()).getAsJsonArray();
				if (versions.isEmpty()) {
					status = "No file for " + GAME_VERSION;
					version++;
					return;
				}
				JsonArray files = versions.get(0).getAsJsonObject().getAsJsonArray("files");
				JsonObject file = files.get(0).getAsJsonObject();
				for (JsonElement f : files) {
					JsonObject o = f.getAsJsonObject();
					if (o.has("primary") && o.get("primary").getAsBoolean()) file = o;
				}
				String fileUrl = file.get("url").getAsString();
				String fileName = cleanName(file.get("filename").getAsString());
				HttpResponse<byte[]> data = HTTP.send(request(fileUrl), HttpResponse.BodyHandlers.ofByteArray());
				if (data.statusCode() != 200) {
					status = "Download failed (HTTP " + data.statusCode() + ")";
					version++;
					return;
				}
				Path dir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
				Files.createDirectories(dir);
				Files.write(dir.resolve(fileName), data.body());
				status = "Saved " + fileName + ". Turn it on in Options > Resource Packs";
			} catch (Exception e) {
				ValerianClient.LOGGER.warn("Texture download failed", e);
				status = "Download failed";
			}
			version++;
		});
	}
}
