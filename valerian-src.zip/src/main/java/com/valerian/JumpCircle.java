package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/** A ring of particles that spreads out from your feet when you jump. */
public final class JumpCircle {
	public static final String[] COLORS = {"White", "Purple", "Blue", "Orange", "Green"};

	private static boolean wasOnGround = true;
	private static int ticksLeft = 0;
	private static double cx;
	private static double cy;
	private static double cz;

	private JumpCircle() {}

	private static ParticleEffect effect() {
		switch (Config.get("jump.color", "Purple")) {
			case "White":
				return ParticleTypes.END_ROD;
			case "Blue":
				return ParticleTypes.SOUL_FIRE_FLAME;
			case "Orange":
				return ParticleTypes.FLAME;
			case "Green":
				return ParticleTypes.HAPPY_VILLAGER;
			default:
				return ParticleTypes.WITCH;
		}
	}

	public static void tick(MinecraftClient mc, ClientPlayerEntity p) {
		boolean onGround = p.isOnGround();
		if (!ModuleManager.isEnabled("JumpCircle") || mc.world == null) {
			ticksLeft = 0;
			wasOnGround = onGround;
			return;
		}
		if (wasOnGround && !onGround && p.getVelocity().y > 0.1) {
			ticksLeft = 14;
			cx = p.getX();
			cy = p.getY();
			cz = p.getZ();
		}
		wasOnGround = onGround;
		if (ticksLeft > 0) {
			int t = 14 - ticksLeft;
			double radius = 0.4 + t * 0.2;
			int points = 30;
			ParticleEffect fx = effect();
			for (int i = 0; i < points; i++) {
				double a = i * Math.PI * 2.0 / points;
				mc.world.addParticleClient(fx, cx + Math.cos(a) * radius, cy + 0.05, cz + Math.sin(a) * radius, 0.0, 0.0, 0.0);
			}
			ticksLeft--;
		}
	}
}
