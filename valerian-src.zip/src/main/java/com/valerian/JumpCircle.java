package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.DustParticleEffect;

/** A ring of coloured dust that spreads out from your feet when you jump. */
public final class JumpCircle {
	public static final String[] COLORS = {"Accent", "White", "Purple", "Blue", "Pink", "Orange", "Green"};

	private static boolean wasOnGround = true;
	private static int ticksLeft = 0;
	private static double cx;
	private static double cy;
	private static double cz;

	private JumpCircle() {}

	private static int rgb() {
		switch (Config.get("jump.color", "Accent")) {
			case "White":
				return 0xFFFFFF;
			case "Purple":
				return 0xA060FF;
			case "Blue":
				return 0x4F9BFF;
			case "Pink":
				return 0xFF5CB8;
			case "Orange":
				return 0xFFA24F;
			case "Green":
				return 0x4FFFA0;
			default:
				return Theme.COLORS[Theme.index()];
		}
	}

	public static void tick(MinecraftClient mc, ClientPlayerEntity p) {
		boolean onGround = p.isOnGround();
		if (!ModuleManager.isEnabled("JumpCircle") || mc.world == null) {
			ticksLeft = 0;
			wasOnGround = onGround;
			return;
		}
		boolean jumped = wasOnGround && !onGround && (p.getVelocity().y > 0.05 || mc.options.jumpKey.isPressed());
		if (jumped) {
			ticksLeft = 14;
			cx = p.getX();
			cy = p.getY();
			cz = p.getZ();
		}
		wasOnGround = onGround;
		if (ticksLeft > 0) {
			int t = 14 - ticksLeft;
			double radius = 0.35 + t * 0.22;
			int points = Math.max(24, (int) (radius * 22));
			DustParticleEffect fx = new DustParticleEffect(rgb(), 0.7f);
			for (int i = 0; i < points; i++) {
				double a = i * Math.PI * 2.0 / points;
				mc.world.addParticleClient(fx, cx + Math.cos(a) * radius, cy + 0.08, cz + Math.sin(a) * radius, 0.0, 0.0, 0.0);
			}
			ticksLeft--;
		}
	}
}
