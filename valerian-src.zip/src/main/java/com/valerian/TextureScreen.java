package com.valerian;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Browse texture packs with previews, download counts and more, and download them without leaving the game. */
public class TextureScreen extends Screen {
	private static final int ROW_H = 46;
	private static String query = "";
	private static int page = 0;

	private TextFieldWidget field;
	private final int shownVersion;

	public TextureScreen() {
		super(Text.literal("Textures"));
		this.shownVersion = TextureDownloader.version();
	}

	private static String count(int n) {
		if (n >= 1_000_000) return (n / 100_000) / 10.0 + "M";
		if (n >= 1000) return (n / 100) / 10.0 + "k";
		return String.valueOf(n);
	}

	private int rows() {
		return this.height >= 290 ? 4 : 3;
	}

	private int top() {
		int total = 28 + rows() * ROW_H + 26 + 14;
		return Math.max(2, (this.height - total) / 2);
	}

	private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		c.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
			c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
		}
	}

	private static void drawThumb(DrawContext c, int[] px, int x, int y) {
		int w = TextureDownloader.THUMB_W;
		int h = TextureDownloader.THUMB_H;
		for (int row = 0; row < h; row++) {
			int start = 0;
			int cur = px[row * w];
			for (int col = 1; col <= w; col++) {
				boolean end = col == w;
				int v = end ? 0 : px[row * w + col];
				if (end || v != cur) {
					c.fill(x + start, y + row, x + col, y + row + 1, 0xFF000000 | cur);
					start = col;
					cur = v;
				}
			}
		}
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y0 = top();

		field = new TextFieldWidget(this.textRenderer, cx - 150, y0, 225, 20, Text.literal("Search"));
		field.setMaxLength(40);
		field.setText(query);
		addDrawableChild(field);

		addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> {
			query = field.getText().trim();
			page = 0;
			TextureDownloader.search(query, page, rows());
		}).dimensions(cx + 80, y0, 70, 20).build());

		int ry = y0 + 28;
		List<TextureDownloader.Pack> packs = TextureDownloader.results();
		for (int i = 0; i < packs.size() && i < rows(); i++) {
			final TextureDownloader.Pack pk = packs.get(i);
			addDrawableChild(ButtonWidget.builder(Text.literal("Get"), b -> TextureDownloader.download(pk))
				.dimensions(cx + 94, ry + i * ROW_H + 10, 56, 22).build());
		}

		int ny = ry + rows() * ROW_H + 2;
		ButtonWidget prev = ButtonWidget.builder(Text.literal("< Prev"), b -> {
			if (page > 0) {
				page--;
				TextureDownloader.search(query, page, rows());
			}
		}).dimensions(cx - 150, ny, 70, 20).build();
		prev.active = page > 0;
		addDrawableChild(prev);
		addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
			page++;
			TextureDownloader.search(query, page, rows());
		}).dimensions(cx - 75, ny, 70, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Back to menu"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx + 30, ny, 120, 20).build());
	}

	@Override
	public void tick() {
		super.tick();
		if (!TextureDownloader.loadedOnce()) {
			TextureDownloader.search(query, page, rows());
			return;
		}
		if (TextureDownloader.version() != shownVersion) {
			MinecraftClient.getInstance().setScreen(new TextureScreen());
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		MinecraftClient mc = MinecraftClient.getInstance();
		int cx = this.width / 2;
		int y0 = top();
		int ry = y0 + 28;
		int accent = Theme.accent();

		List<TextureDownloader.Pack> packs = TextureDownloader.results();
		for (int i = 0; i < packs.size() && i < rows(); i++) {
			TextureDownloader.Pack pk = packs.get(i);
			int y = ry + i * ROW_H;
			roundRect(context, cx - 150, y, 240, ROW_H - 4, 5, 0xE015151B);

			int tx = cx - 146;
			int ty = y + 3;
			int[] thumb = TextureDownloader.thumb(pk.id());
			if (thumb != null && thumb.length == TextureDownloader.THUMB_W * TextureDownloader.THUMB_H) {
				drawThumb(context, thumb, tx, ty);
			} else {
				roundRect(context, tx, ty, TextureDownloader.THUMB_W, TextureDownloader.THUMB_H, 4, 0xFF22222F);
				String letter = pk.title().isEmpty() ? "?" : pk.title().substring(0, 1).toUpperCase();
				String hint = thumb == null ? "..." : letter;
				context.drawTextWithShadow(mc.textRenderer, hint,
					tx + (TextureDownloader.THUMB_W - mc.textRenderer.getWidth(hint)) / 2,
					ty + (TextureDownloader.THUMB_H - 8) / 2, accent);
			}

			int textX = cx - 76;
			int maxW = 162;
			context.drawTextWithShadow(mc.textRenderer, mc.textRenderer.trimToWidth(pk.title(), maxW), textX, y + 3, 0xFFFFFFFF);
			context.drawTextWithShadow(mc.textRenderer, mc.textRenderer.trimToWidth("by " + pk.author(), maxW), textX, y + 13, 0xFF9A9AAE);
			context.drawTextWithShadow(mc.textRenderer,
				mc.textRenderer.trimToWidth("Downloads " + count(pk.downloads()) + "   Follows " + count(pk.follows()), maxW),
				textX, y + 23, accent);
			context.drawTextWithShadow(mc.textRenderer, mc.textRenderer.trimToWidth(pk.desc(), maxW), textX, y + 33, 0xFF77778A);
		}

		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Textures (Modrinth, 1.21.11)"),
			cx, Math.max(0, y0 - 12), accent);
		int ny = ry + rows() * ROW_H + 2;
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(TextureDownloader.status()),
			cx, ny + 26, 0xFFCCCCDD);
	}
}
