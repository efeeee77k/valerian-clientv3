package com.valerian;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Browse and download texture packs without leaving the game. */
public class TextureScreen extends Screen {
	private static String query = "";
	private static int page = 0;

	private TextFieldWidget field;
	private final int shownVersion;

	public TextureScreen() {
		super(Text.literal("Textures"));
		this.shownVersion = TextureDownloader.version();
	}

	private static String count(int n) {
		if (n >= 1_000_000) return (n / 100_000) / 10.0 + "M";
		if (n >= 1000) return (n / 100) / 10.0 + "k";
		return String.valueOf(n);
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y0 = this.height / 2 - 100;

		field = new TextFieldWidget(this.textRenderer, cx - 150, y0, 225, 20, Text.literal("Search"));
		field.setMaxLength(40);
		field.setText(query);
		addDrawableChild(field);

		addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> {
			query = field.getText().trim();
			page = 0;
			TextureDownloader.search(query, page);
		}).dimensions(cx + 80, y0, 70, 20).build());

		List<TextureDownloader.Pack> packs = TextureDownloader.results();
		for (int i = 0; i < packs.size() && i < 6; i++) {
			final TextureDownloader.Pack pk = packs.get(i);
			String label = pk.title() + "  (" + count(pk.downloads()) + " downloads)";
			addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> TextureDownloader.download(pk))
				.dimensions(cx - 150, y0 + 26 + i * 24, 300, 20).build());
		}

		int ny = y0 + 26 + 6 * 24 + 2;
		ButtonWidget prev = ButtonWidget.builder(Text.literal("< Prev"), b -> {
			if (page > 0) {
				page--;
				TextureDownloader.search(query, page);
			}
		}).dimensions(cx - 150, ny, 70, 20).build();
		prev.active = page > 0;
		addDrawableChild(prev);
		addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
			page++;
			TextureDownloader.search(query, page);
		}).dimensions(cx - 75, ny, 70, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Back to menu"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx + 30, ny, 120, 20).build());
	}

	@Override
	public void tick() {
		super.tick();
		if (!TextureDownloader.loadedOnce()) {
			TextureDownloader.search(query, page);
			return;
		}
		if (TextureDownloader.version() != shownVersion) {
			MinecraftClient.getInstance().setScreen(new TextureScreen());
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Textures (Modrinth, 1.21.11)"),
			this.width / 2, this.height / 2 - 116, Theme.accent());
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(TextureDownloader.status()),
			this.width / 2, this.height / 2 + 82, 0xFFCCCCDD);
	}
}
