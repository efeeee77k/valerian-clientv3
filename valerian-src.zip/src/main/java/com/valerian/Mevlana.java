package com.valerian;

import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Spins your own model on screen, head included. Only client side angles change, so it is
 * only visible in third person and nothing is sent to the server.
 */
public final class Mevlana {
	private static float spin = 0f;
	private static boolean active = false;

	private Mevlana() {}

	public static void tick(ClientPlayerEntity p) {
		if (!ModuleManager.isEnabled("Mevlana")) {
			active = false;
			return;
		}
		if (!active) {
			spin = p.getBodyYaw();
			active = true;
		}
		int speed = Math.max(1, Math.min(5, Config.getInt("mevlana.speed", 3)));
		spin = (spin + speed * 6f) % 360f;
		p.setBodyYaw(spin);
		if (!Config.get("mevlana.head", "On").equals("Off")) {
			p.setHeadYaw(spin);
		}
	}
}
