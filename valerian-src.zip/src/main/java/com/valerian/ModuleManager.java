package com.valerian;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
	public record Mod(String name, String category, boolean implemented, boolean defaultOn, String desc, boolean danger) {}

	/** Tabs that hold modules. HUDItem entries are sub-settings of the HUD module and have no tab. */
	public static final String[] CATEGORIES = {"HUD", "Visual", "Player"};
	public static final List<Mod> ALL = new ArrayList<>();
	private static final Map<String, Mod> BY_NAME = new HashMap<>();

	private static void add(String category, String name, boolean implemented, boolean defaultOn, String desc, boolean danger) {
		Mod m = new Mod(name, category, implemented, defaultOn, desc, danger);
		ALL.add(m);
		BY_NAME.put(name, m);
	}

	private static void add(String category, String name, boolean implemented, boolean defaultOn, String desc) {
		add(category, name, implemented, defaultOn, desc, false);
	}

	static {
		add("HUD", "HUD", true, true, "FPS, XYZ, ping, armor, keystrokes and more");
		add("Visual", "Hitbox", true, false, "Shows entity hitboxes");
		add("Visual", "SwingSpeed", true, false, "Slows the hand swing animation");
		add("Visual", "SkinProtect", true, false, "Wear the skin of any premium account");
		add("Visual", "Cosmetics", true, true, "Hats, halos, horns and wings");
		add("Visual", "JumpCircle", true, false, "A ring appears under you when you jump");
		add("Visual", "CustomWeapons", true, false, "New models for swords, axes and bows");
		add("Visual", "Mevlana", true, false, "Your model spins in third person", true);
		add("Player", "Sprint", true, false, "Always sprint while moving forward");
		add("Player", "NameProtect", true, false, "Hides your real name and others");
		add("Player", "ChatKeybind", true, true, "Send chat messages with a key");
		add("Player", "Friends", true, true, "Friends get your skin and a green name");
		add("Player", "Pets", true, false, "A pet that follows you around");
		add("HUDItem", "FPS", true, true, "");
		add("HUDItem", "XYZ", true, true, "");
		add("HUDItem", "Ping", true, true, "");
		add("HUDItem", "Direction", true, true, "");
		add("HUDItem", "Armor", true, true, "");
		add("HUDItem", "Keystrokes", true, true, "");
		add("HUDItem", "Potion", true, true, "");
		add("HUDItem", "TargetHUD", true, true, "");
	}

	private ModuleManager() {}

	public static boolean isEnabled(String name) {
		Mod m = BY_NAME.get(name);
		return Config.getBool("mod." + name, m != null && m.defaultOn());
	}

	public static void toggle(String name) {
		Config.set("mod." + name, String.valueOf(!isEnabled(name)));
		Config.save();
	}

	public static List<Mod> forCategory(String category) {
		List<Mod> out = new ArrayList<>();
		for (Mod m : ALL) {
			if (m.category().equals(category)) out.add(m);
		}
		return out;
	}
}
