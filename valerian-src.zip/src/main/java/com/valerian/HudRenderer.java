package com.valerian;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class HudRenderer {
	public abstract static class Element {
		public final String name;
		public final int defX;
		public final int defY;
		public int w = 60;
		public int h = 14;
		/** Standalone elements are shown even when the HUD module is off. */
		public boolean standalone = false;

		Element(String name, int defX, int defY) {
			this.name = name;
			this.defX = defX;
			this.defY = defY;
		}

		public int getX() {
			return Config.getInt("hud." + name + ".x", defX);
		}

		public int getY() {
			return Config.getInt("hud." + name + ".y", defY);
		}

		public void setPos(int x, int y) {
			Config.set("hud." + name + ".x", String.valueOf(x));
			Config.set("hud." + name + ".y", String.valueOf(y));
		}

		public void resetPos() {
			Config.remove("hud." + name + ".x");
			Config.remove("hud." + name + ".y");
		}

		/** Draws the element at x,y and updates w and h. */
		public abstract void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit);
	}

	public static final List<Element> ELEMENTS = new ArrayList<>();

	private static final int BG = 0xAA15151B;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFA8A8B4;
	private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

	private record Tok(String text, int color) {}

	private static final java.util.ArrayDeque<Long> LEFT_CLICKS = new java.util.ArrayDeque<>();
	private static final java.util.ArrayDeque<Long> RIGHT_CLICKS = new java.util.ArrayDeque<>();
	private static boolean lastAttack = false;
	private static boolean lastUse = false;

	private static int cps(java.util.ArrayDeque<Long> q, boolean down, boolean last) {
		long now = System.currentTimeMillis();
		if (down && !last) q.addLast(now);
		while (!q.isEmpty() && now - q.peekFirst() > 1000L) q.pollFirst();
		return q.size();
	}

	private static double bpsValue = 0.0;
	private static double bpsX = 0.0;
	private static double bpsZ = 0.0;
	private static long bpsTime = 0L;

	private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		c.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
			c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
		}
	}

	private static void box(DrawContext c, int x, int y, int w, int h) {
		roundRect(c, x, y, w, h, 4, BG);
		c.fill(x, y + 3, x + 2, y + h - 3, Theme.accent());
	}

	private static double bps(MinecraftClient mc) {
		long now = System.nanoTime();
		if (bpsTime == 0L || now - bpsTime > 250_000_000L) {
			double dx = mc.player.getX() - bpsX;
			double dz = mc.player.getZ() - bpsZ;
			if (bpsTime != 0L) {
				bpsValue = Math.sqrt(dx * dx + dz * dz) / ((now - bpsTime) / 1.0E9);
			}
			bpsX = mc.player.getX();
			bpsZ = mc.player.getZ();
			bpsTime = now;
		}
		return bpsValue;
	}

	private static int countTotems(MinecraftClient mc) {
		PlayerInventory inv = mc.player.getInventory();
		int n = 0;
		for (int i = 0; i < inv.size(); i++) {
			ItemStack st = inv.getStack(i);
			if (st.isOf(Items.TOTEM_OF_UNDYING)) n += st.getCount();
		}
		return n;
	}

	private static int lineWidth(MinecraftClient mc, List<Tok> line) {
		int w = 0;
		for (Tok t : line) w += mc.textRenderer.getWidth(t.text());
		return w;
	}

	private static void textBox(Element e, DrawContext c, MinecraftClient mc, int x, int y, List<String> lines, List<Integer> colors) {
		int maxW = 0;
		for (String s : lines) maxW = Math.max(maxW, mc.textRenderer.getWidth(s));
		e.w = maxW + 10;
		e.h = lines.size() * 11 + 4;
		box(c, x, y, e.w, e.h);
		for (int i = 0; i < lines.size(); i++) {
			c.drawTextWithShadow(mc.textRenderer, lines.get(i), x + 6, y + 3 + i * 11, colors.get(i));
		}
	}

	private static void single(Element e, DrawContext c, MinecraftClient mc, int x, int y, String text) {
		List<String> l = new ArrayList<>();
		l.add(text);
		List<Integer> col = new ArrayList<>();
		col.add(WHITE);
		textBox(e, c, mc, x, y, l, col);
	}

	private static String time(int seconds) {
		return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
	}

	private static void keyBox(DrawContext c, MinecraftClient mc, int x, int y, int w, int h, String label, boolean down) {
		roundRect(c, x, y, w, h, 3, down ? 0xCCB388FF : BG);
		int tw = mc.textRenderer.getWidth(label);
		c.drawTextWithShadow(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, WHITE);
	}

	static {
		ELEMENTS.add(new Element("Info", 6, 6) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				List<List<Tok>> lines = new ArrayList<>();
				boolean has = mc.player != null;
				if (ModuleManager.isEnabled("Coordinates")) {
					List<Tok> l = new ArrayList<>();
					l.add(new Tok("xyz: ", GRAY));
					String v = has
						? (int) Math.floor(mc.player.getX()) + "  " + (int) Math.floor(mc.player.getY()) + "  " + (int) Math.floor(mc.player.getZ())
						: "0  0  0";
					l.add(new Tok(v, WHITE));
					lines.add(l);
				}
				List<Tok> stats = new ArrayList<>();
				if (ModuleManager.isEnabled("FPS")) {
					stats.add(new Tok(String.valueOf(mc.getCurrentFps()), WHITE));
					stats.add(new Tok(" fps", GRAY));
				}
				if (ModuleManager.isEnabled("Ping")) {
					int ping = 0;
					if (has && mc.getNetworkHandler() != null) {
						PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
						if (entry != null) ping = entry.getLatency();
					}
					if (!stats.isEmpty()) stats.add(new Tok("   ", GRAY));
					stats.add(new Tok(String.valueOf(ping), WHITE));
					stats.add(new Tok("ms", GRAY));
				}
				if (ModuleManager.isEnabled("BPS")) {
					if (!stats.isEmpty()) stats.add(new Tok("   ", GRAY));
					stats.add(new Tok(String.format("%.1f", has ? bps(mc) : 0.0), WHITE));
					stats.add(new Tok(" bps", GRAY));
				}
				if (!stats.isEmpty()) lines.add(stats);
				if (ModuleManager.isEnabled("Totems")) {
					List<Tok> l = new ArrayList<>();
					l.add(new Tok("totems: ", GRAY));
					l.add(new Tok(String.valueOf(has ? countTotems(mc) : 0), WHITE));
					lines.add(l);
				}
				if (ModuleManager.isEnabled("Time")) {
					List<Tok> l = new ArrayList<>();
					l.add(new Tok("time: ", GRAY));
					l.add(new Tok(LocalTime.now().format(TIME_FMT), WHITE));
					lines.add(l);
				}
				if (lines.isEmpty()) {
					if (!edit) return;
					List<Tok> l = new ArrayList<>();
					l.add(new Tok("info panel", GRAY));
					lines.add(l);
				}
				int maxW = 0;
				for (List<Tok> line : lines) maxW = Math.max(maxW, lineWidth(mc, line));
				w = maxW + 14;
				h = lines.size() * 11 + 6;
				box(c, x, y, w, h);
				for (int i = 0; i < lines.size(); i++) {
					int tx = x + 8;
					int ty = y + 4 + i * 11;
					for (Tok t : lines.get(i)) {
						c.drawTextWithShadow(mc.textRenderer, t.text(), tx, ty, t.color());
						tx += mc.textRenderer.getWidth(t.text());
					}
				}
			}
		});
		ELEMENTS.add(new Element("ModuleList", 330, 6) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				List<String> names = new ArrayList<>();
				for (ModuleManager.Mod m : ModuleManager.ALL) {
					if (m.category().equals("HUDItem") || m.name().equals("HUD")) continue;
					if (m.implemented() && ModuleManager.isEnabled(m.name())) names.add(m.name());
				}
				if (names.isEmpty()) {
					if (!edit) return;
					names.add("Module list");
				}
				names.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));
				int maxW = 0;
				for (String n : names) maxW = Math.max(maxW, mc.textRenderer.getWidth(n));
				w = maxW + 14;
				h = names.size() * 11 + 6;
				box(c, x, y, w, h);
				for (int i = 0; i < names.size(); i++) {
					int tw = mc.textRenderer.getWidth(names.get(i));
					c.drawTextWithShadow(mc.textRenderer, names.get(i), x + w - 6 - tw, y + 4 + i * 11, Theme.accent());
				}
			}
		});
		ELEMENTS.add(new Element("Direction", 6, 60) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				String s = "Facing: -";
				if (mc.player != null) {
					s = "Facing: " + mc.player.getHorizontalFacing().asString().toUpperCase();
				}
				single(this, c, mc, x, y, s);
			}
		});
		ELEMENTS.add(new Element("Armor", 6, 80) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
				String[] names = {"Helmet", "Chest", "Legs", "Boots"};
				List<String> lines = new ArrayList<>();
				List<Integer> colors = new ArrayList<>();
				for (int i = 0; i < slots.length; i++) {
					ItemStack stack = mc.player != null ? mc.player.getEquippedStack(slots[i]) : ItemStack.EMPTY;
					if (stack.isEmpty() || !stack.isDamageable()) {
						lines.add(names[i] + ": -");
						colors.add(0xFF888888);
					} else {
						int max = stack.getMaxDamage();
						int pct = Math.round((max - stack.getDamage()) * 100f / max);
						lines.add(names[i] + ": " + pct + "%");
						colors.add(pct > 50 ? 0xFF66FF66 : (pct > 20 ? 0xFFFFDD55 : 0xFFFF5555));
					}
				}
				textBox(this, c, mc, x, y, lines, colors);
			}
		});
		ELEMENTS.add(new Element("Keystrokes", 6, 140) {
			{
				standalone = true;
			}

			@Override
			public int getX() {
				return Config.getInt("hud.Keystrokes.x", Math.max(0, MinecraftClient.getInstance().getWindow().getScaledWidth() - 70));
			}

			@Override
			public int getY() {
				return Config.getInt("hud.Keystrokes.y", Math.max(0, MinecraftClient.getInstance().getWindow().getScaledHeight() - 100));
			}

			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				int s = 18;
				int g = 2;
				boolean mouse = !Config.get("keys.mouse", "On").equals("Off");
				boolean sneak = !Config.get("keys.sneak", "On").equals("Off");
				w = 3 * s + 2 * g;
				int row = 0;
				keyBox(c, mc, x + s + g, y, s, s, "W", mc.options.forwardKey.isPressed());
				keyBox(c, mc, x, y + s + g, s, s, "A", mc.options.leftKey.isPressed());
				keyBox(c, mc, x + s + g, y + s + g, s, s, "S", mc.options.backKey.isPressed());
				keyBox(c, mc, x + 2 * (s + g), y + s + g, s, s, "D", mc.options.rightKey.isPressed());
				int cy = y + 2 * (s + g);
				keyBox(c, mc, x, cy, w, 12, "SPACE", mc.options.jumpKey.isPressed());
				cy += 14;
				if (sneak) {
					int bw = (w - g) / 2;
					keyBox(c, mc, x, cy, bw, 12, "SNK", mc.options.sneakKey.isPressed());
					keyBox(c, mc, x + bw + g, cy, bw, 12, "SPR", mc.options.sprintKey.isPressed());
					cy += 14;
				}
				if (mouse) {
					boolean atk = mc.options.attackKey.isPressed();
					boolean use = mc.options.useKey.isPressed();
					int l = cps(LEFT_CLICKS, atk, lastAttack);
					int r = cps(RIGHT_CLICKS, use, lastUse);
					lastAttack = atk;
					lastUse = use;
					int bw = (w - g) / 2;
					roundRect(c, x, cy, bw, 18, 3, atk ? 0xCCB388FF : BG);
					roundRect(c, x + bw + g, cy, bw, 18, 3, use ? 0xCCB388FF : BG);
					c.drawTextWithShadow(mc.textRenderer, "LMB", x + (bw - mc.textRenderer.getWidth("LMB")) / 2, cy + 1, WHITE);
					c.drawTextWithShadow(mc.textRenderer, "RMB", x + bw + g + (bw - mc.textRenderer.getWidth("RMB")) / 2, cy + 1, WHITE);
					String ls = String.valueOf(l);
					String rs = String.valueOf(r);
					c.drawTextWithShadow(mc.textRenderer, ls, x + (bw - mc.textRenderer.getWidth(ls)) / 2, cy + 9, GRAY);
					c.drawTextWithShadow(mc.textRenderer, rs, x + bw + g + (bw - mc.textRenderer.getWidth(rs)) / 2, cy + 9, GRAY);
					cy += 20;
				}
				h = cy - y;
			}
		});
		ELEMENTS.add(new Element("Potion", 110, 6) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				List<String> lines = new ArrayList<>();
				List<Integer> colors = new ArrayList<>();
				if (mc.player != null) {
					for (StatusEffectInstance e : mc.player.getStatusEffects()) {
						String n = e.getEffectType().value().getName().getString();
						String t = e.getDuration() < 0 ? "inf" : time(e.getDuration() / 20);
						lines.add(n + " " + (e.getAmplifier() + 1) + " - " + t);
						colors.add(WHITE);
					}
				}
				if (lines.isEmpty()) {
					if (!edit) return;
					lines.add("Speed 2 - 0:30");
					colors.add(0xFF888888);
				}
				textBox(this, c, mc, x, y, lines, colors);
			}
		});
		ELEMENTS.add(new Element("TargetHUD", 200, 100) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				String name = "Target";
				float hp = 20f;
				float max = 20f;
				Entity t = mc.targetedEntity;
				if (t instanceof LivingEntity le) {
					name = NameProtect.apply(le.getName().getString());
					hp = le.getHealth();
					max = Math.max(1f, le.getMaxHealth());
				} else if (!edit) {
					return;
				}
				w = 100;
				h = 28;
				box(c, x, y, w, h);
				int nameColor = ModuleManager.isEnabled("Friends") && FriendManager.isFriend(name) ? 0xFF66FF66 : WHITE;
				c.drawTextWithShadow(mc.textRenderer, name, x + 6, y + 3, nameColor);
				c.fill(x + 6, y + 16, x + 94, y + 22, 0xFF333344);
				int fill = Math.round(88 * Math.min(1f, hp / max));
				c.fill(x + 6, y + 16, x + 6 + fill, y + 22, 0xFFFF5555);
				String hs = Math.round(hp * 10f) / 10f + " HP";
				c.drawTextWithShadow(mc.textRenderer, hs, x + 60, y + 3, 0xFFCCCCCC);
			}
		});
	}

	private HudRenderer() {}

	public static void register() {
		HudRenderCallback.EVENT.register((context, tickCounter) -> renderAll(context));
	}

	private static void renderAll(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;
		if (mc.currentScreen instanceof HudEditScreen) return;
		boolean hudOn = ModuleManager.isEnabled("HUD");
		for (Element e : ELEMENTS) {
			if (ModuleManager.isEnabled(e.name) && (hudOn || e.standalone)) {
				e.draw(context, mc, e.getX(), e.getY(), false);
			}
		}
	}
}
