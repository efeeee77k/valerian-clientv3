package com.valerian;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Modern menu: sidebar with tabs, search, module cards with switches.
 * Left click a card to switch it, right click (or the arrow) to open its settings.
 */
public class ValerianScreen extends Screen {
	private interface Setting {
		String label();

		void left();

		void right();
	}

	private record Card(ModuleManager.Mod mod, int x, int y, int w, int h, List<Setting> settings, boolean expanded) {
		boolean contains(int mx, int my, int scroll) {
			return mx >= x && mx < x + w && my >= y - scroll && my < y - scroll + h;
		}
	}

	private static final String[] TABS = {"HUD", "Visual", "Player", "Cosmetics", "Controls", "Textures"};
	private static boolean typing = false;

	public static boolean isTyping() {
		return typing;
	}
	private static String currentTab = "HUD";
	private static final Set<String> EXPANDED = new HashSet<>();
	private static final Map<String, Float> ANIM = new HashMap<>();

	private static final int SIDEBAR = 84;
	private static final int CARD_H = 34;
	private static final int SROW = 14;
	private static final int GAP = 6;

	private boolean wasLeft = true;
	private boolean wasRight = true;
	private int scroll = 0;
	private int contentBottom = 0;
	private String lastQuery = "";
	private TextFieldWidget search;

	public ValerianScreen() {
		super(Text.literal("Valerian Client"));
	}

	private static String onOff(boolean on) {
		return on ? "ON" : "OFF";
	}

	private static Setting action(String label, Runnable r) {
		return new Setting() {
			public String label() {
				return label;
			}

			public void left() {
				r.run();
			}

			public void right() {
			}
		};
	}

	private static Setting cycleSetting(String label, String key, String[] options, String def) {
		return new Setting() {
			private String cur() {
				String v = Config.get(key, def);
				for (String o : options) {
					if (o.equals(v)) return v;
				}
				return def;
			}

			private void step(int d) {
				String c = cur();
				int i = 0;
				for (int k = 0; k < options.length; k++) {
					if (options[k].equals(c)) i = k;
				}
				i = (i + d + options.length) % options.length;
				Config.set(key, options[i]);
				Config.save();
			}

			public String label() {
				return label + ": " + cur();
			}

			public void left() {
				step(1);
			}

			public void right() {
				step(-1);
			}
		};
	}

	private static Setting toggleSetting(String label, String module) {
		return new Setting() {
			public String label() {
				return label + ": " + onOff(ModuleManager.isEnabled(module));
			}

			public void left() {
				ModuleManager.toggle(module);
			}

			public void right() {
				ModuleManager.toggle(module);
			}
		};
	}

	private static List<Setting> settings(String module) {
		List<Setting> l = new ArrayList<>();
		switch (module) {
			case "HUD" -> {
				String[][] hudItems = {
					{"Coordinates", "Coordinates"}, {"FPS", "FPS"}, {"Ping", "Ping"}, {"BPS", "Blocks / sec"},
					{"Totems", "Totems"}, {"Time", "Time"}, {"ModuleList", "Module List"}, {"Direction", "Direction"},
					{"Armor", "Armor"}, {"Potion", "Potion"}, {"TargetHUD", "Target HUD"}
				};
				for (String[] item : hudItems) {
					l.add(toggleSetting(item[1], item[0]));
				}
				l.add(action("Edit positions >", () -> MinecraftClient.getInstance().setScreen(new HudEditScreen())));
			}
			case "SwingSpeed" -> l.add(new Setting() {
				public String label() {
					return "Slowdown: " + Math.max(1, Math.min(3, Config.getInt("swing.level", 3))) + "/3";
				}

				public void left() {
					int v = Math.max(1, Math.min(3, Config.getInt("swing.level", 3)));
					Config.set("swing.level", String.valueOf(v >= 3 ? 1 : v + 1));
					Config.save();
				}

				public void right() {
					int v = Math.max(1, Math.min(3, Config.getInt("swing.level", 3)));
					Config.set("swing.level", String.valueOf(v <= 1 ? 3 : v - 1));
					Config.save();
				}
			});
			case "ChatKeybind" -> l.add(action("Edit binds >", () -> MinecraftClient.getInstance().setScreen(new ChatBindsScreen(-1))));
			case "Friends" -> l.add(action("Manage friends >", () -> MinecraftClient.getInstance().setScreen(new FriendsScreen())));
			case "Pets" -> l.add(new Setting() {
				public String label() {
					return "Pet: " + PetManager.selected();
				}

				public void left() {
					PetManager.cycle(1);
				}

				public void right() {
					PetManager.cycle(-1);
				}
			});
			case "Keystrokes" -> {
				l.add(cycleSetting("Mouse buttons", "keys.mouse", new String[] {"On", "Off"}, "On"));
				l.add(cycleSetting("Sneak / Sprint", "keys.sneak", new String[] {"On", "Off"}, "On"));
				l.add(action("Move it >", () -> MinecraftClient.getInstance().setScreen(new HudEditScreen())));
			}
			case "JumpCircle" -> l.add(cycleSetting("Color", "jump.color", JumpCircle.COLORS, "Accent"));
			case "Mevlana" -> {
				l.add(cycleSetting("Speed", "mevlana.speed", new String[] {"1", "2", "3", "4", "5"}, "3"));
				l.add(cycleSetting("Head spins", "mevlana.head", new String[] {"On", "Off"}, "On"));
			}
			case "CustomWeapons" -> {
				l.add(cycleSetting("Sword", "weapons.sword", new String[] {"Off", "Dagger", "Curved Blade"}, "Dagger"));
				l.add(cycleSetting("Axe", "weapons.axe", new String[] {"Off", "Battle Axe", "Frost Axe"}, "Battle Axe"));
				l.add(cycleSetting("Bow", "weapons.bow", new String[] {"Off", "Rifle"}, "Rifle"));
			}
			case "Cosmetics" -> l.add(action("Open lobby >", () ->
				MinecraftClient.getInstance().setScreen(new CosmeticsScreen(Cosmetics.Slot.HEAD, null))));
			case "NameProtect" -> {
				final String own = NameProtect.ownFake();
				final String oth = NameProtect.othersFake();
				l.add(action("Your name: " + own + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Your fake name", own, NameProtect::setOwn))));
				l.add(action("Others: " + (oth.isEmpty() ? "OFF" : oth) + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Name for other players (empty = off)", oth, NameProtect::setOthers))));
			}
			case "SkinProtect" -> {
				final String acc = SkinManager.account();
				l.add(action("Account: " + (acc.isEmpty() ? "none" : acc) + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Premium account name", acc, SkinManager::setAccount))));
				l.add(action("Reload skin", SkinManager::reload));
				l.add(action(SkinManager.status(), () -> { }));
			}
			default -> { }
		}
		return l;
	}


	// ----- geometry -----
	private int winW() {
		return Math.min(this.width - 12, 400);
	}

	private int winH() {
		return Math.min(this.height - 12, 250);
	}

	private int winX() {
		return (this.width - winW()) / 2;
	}

	private int winY() {
		return (this.height - winH()) / 2;
	}

	private int contentX() {
		return winX() + SIDEBAR + 8;
	}

	private int contentW() {
		return winW() - SIDEBAR - 16;
	}

	private int areaTop() {
		return winY() + 30;
	}

	private int areaBottom() {
		return winY() + winH() - 20;
	}

	@Override
	protected void init() {
		search = new TextFieldWidget(this.textRenderer, contentX() + 6, winY() + 11, contentW() - 100, 12, Text.literal("Search"));
		search.setMaxLength(24);
		search.setDrawsBackground(false);
		addSelectableChild(search);
	}

	// ----- drawing helpers -----
	private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		c.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
			c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
		}
	}

	private static void drawSwitch(DrawContext c, int x, int y, float t, int accent) {
		roundRect(c, x, y, 20, 10, 5, Theme.blend(0x3A3A4C, accent, t));
		roundRect(c, x + 2 + Math.round(t * 10), y + 2, 6, 6, 3, 0xFFFFFFFF);
	}

	private List<ModuleManager.Mod> visibleModules() {
		String q = search == null ? "" : search.getText().trim().toLowerCase();
		List<ModuleManager.Mod> out = new ArrayList<>();
		if (!q.isEmpty()) {
			for (ModuleManager.Mod m : ModuleManager.ALL) {
				if (m.category().equals("HUDItem")) continue;
				if (m.name().toLowerCase().contains(q) || m.desc().toLowerCase().contains(q)) out.add(m);
			}
			return out;
		}
		return ModuleManager.forCategory(currentTab);
	}

	private List<Card> layout(int cx, int cy, int cw) {
		List<Card> cards = new ArrayList<>();
		int colW = (cw - GAP) / 2;
		int[] colY = {cy, cy};
		for (ModuleManager.Mod m : visibleModules()) {
			List<Setting> st = settings(m.name());
			boolean exp = EXPANDED.contains(m.name()) && !st.isEmpty();
			if (exp) {
				int y = Math.max(colY[0], colY[1]);
				int h = CARD_H + 4 + st.size() * SROW + 4;
				cards.add(new Card(m, cx, y, cw, h, st, true));
				colY[0] = y + h + GAP;
				colY[1] = colY[0];
			} else {
				int col = colY[0] <= colY[1] ? 0 : 1;
				cards.add(new Card(m, cx + col * (colW + GAP), colY[col], colW, CARD_H, st, false));
				colY[col] += CARD_H + GAP;
			}
		}
		contentBottom = Math.max(colY[0], colY[1]);
		return cards;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll = Math.max(0, scroll - (int) (verticalAmount * 14));
		return true;
	}

	@Override
	public void render(DrawContext c, int mx, int my, float delta) {
		super.render(c, mx, my, delta);
		MinecraftClient mc = MinecraftClient.getInstance();
		long handle = mc.getWindow().getHandle();
		boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
		boolean leftClick = left && !wasLeft;
		boolean rightClick = right && !wasRight;
		wasLeft = left;
		wasRight = right;

		int accent = Theme.accent();
		int wx = winX();
		int wy = winY();
		int ww = winW();
		int wh = winH();
		int cx = contentX();
		int cw = contentW();
		int top = areaTop();
		int bottom = areaBottom();

		typing = search.isFocused();
		String q = search.getText();
		if (!q.equals(lastQuery)) {
			lastQuery = q;
			scroll = 0;
		}

		List<Card> cards = layout(cx, top + 2, cw);
		int maxScroll = Math.max(0, contentBottom - (bottom - 2));
		scroll = Math.max(0, Math.min(scroll, maxScroll));

		// ---- clicks ----
		if (leftClick || rightClick) {
			boolean handled = false;
			// sidebar tabs
			for (int i = 0; i < TABS.length && !handled; i++) {
				int tx = wx + 6;
				int ty = wy + 36 + i * 22;
				if (mx >= tx && mx < tx + SIDEBAR - 12 && my >= ty && my < ty + 18) {
					handled = true;
					if (!leftClick) break;
					if (TABS[i].equals("Textures")) {
						mc.setScreen(new TextureScreen());
						return;
					}
					if (TABS[i].equals("Controls")) {
						mc.setScreen(new ControlsScreen(-1));
						return;
					}
					if (TABS[i].equals("Cosmetics")) {
						mc.setScreen(new CosmeticsScreen(Cosmetics.Slot.HEAD, null));
						return;
					}
					currentTab = TABS[i];
					search.setText("");
					scroll = 0;
					EXPANDED.clear();
				}
			}
			// accent dots
			int dotsX = cx + cw / 2 - (Theme.COLORS.length * 12) / 2;
			for (int i = 0; i < Theme.COLORS.length && !handled; i++) {
				int dx = dotsX + i * 12;
				int dy = wy + wh - 14;
				if (leftClick && mx >= dx && mx < dx + 10 && my >= dy && my < dy + 10) {
					Theme.set(i);
					handled = true;
				}
			}
			// cards
			if (!handled && mx >= cx && mx < cx + cw && my >= top && my < bottom) {
				for (Card card : cards) {
					if (!card.contains(mx, my, scroll)) continue;
					int localY = my - (card.y() - scroll);
					String name = card.mod().name();
					boolean hasSettings = !card.settings().isEmpty();
					if (localY < CARD_H) {
						boolean arrow = mx >= card.x() + card.w() - 18 && localY >= CARD_H - 15;
						if (leftClick && !arrow) {
							ModuleManager.toggle(name);
						} else if (hasSettings && (rightClick || arrow)) {
							if (!EXPANDED.remove(name)) EXPANDED.add(name);
						}
					} else if (card.expanded()) {
						int row = (localY - CARD_H - 4) / SROW;
						if (row >= 0 && row < card.settings().size()) {
							Setting s = card.settings().get(row);
							if (leftClick) {
								s.left();
							} else {
								s.right();
							}
							if (mc.currentScreen != this) return;
						}
					}
					break;
				}
			}
		}

		// ---- window ----
		roundRect(c, wx - 1, wy - 1, ww + 2, wh + 2, 8, 0xFF2A2A3C);
		roundRect(c, wx, wy, ww, wh, 7, 0xF2101018);
		roundRect(c, wx, wy, SIDEBAR, wh, 7, 0xF20B0B12);
		c.fill(wx + SIDEBAR - 7, wy, wx + SIDEBAR, wy + wh, 0xF20B0B12);

		// sidebar
		c.fill(wx + 12, wy + 10, wx + 15, wy + 22, accent);
		c.drawTextWithShadow(mc.textRenderer, "Valerian", wx + 20, wy + 8, 0xFFFFFFFF);
		c.drawTextWithShadow(mc.textRenderer, "SEE MORE.", wx + 20, wy + 18, 0xFF77778A);
		for (int i = 0; i < TABS.length; i++) {
			int tx = wx + 6;
			int ty = wy + 36 + i * 22;
			boolean sel = TABS[i].equals(currentTab);
			boolean hover = mx >= tx && mx < tx + SIDEBAR - 12 && my >= ty && my < ty + 18;
			if (sel) {
				roundRect(c, tx, ty, SIDEBAR - 12, 18, 4, (accent & 0x00FFFFFF) | 0x66000000);
			} else if (hover) {
				roundRect(c, tx, ty, SIDEBAR - 12, 18, 4, 0x33FFFFFF);
			}
			c.fill(tx + 6, ty + 7, tx + 10, ty + 11, sel ? accent : 0xFF55556A);
			c.drawTextWithShadow(mc.textRenderer, TABS[i], tx + 16, ty + 5, sel ? 0xFFFFFFFF : 0xFFAAAABC);
		}
		c.drawTextWithShadow(mc.textRenderer, "v1.0.0", wx + 12, wy + wh - 14, 0xFF55556A);

		// top bar
		roundRect(c, cx, wy + 8, cw - 90, 16, 5, 0xFF171722);
		if (search.getText().isEmpty() && !search.isFocused()) {
			c.drawTextWithShadow(mc.textRenderer, "Search modules...", cx + 8, wy + 12, 0xFF666678);
		}
		search.render(c, mx, my, delta);
		String title = "VALERIAN";
		int tw = mc.textRenderer.getWidth(title);
		c.drawTextWithShadow(mc.textRenderer, title, wx + ww - 10 - tw, wy + 10, accent);
		c.drawTextWithShadow(mc.textRenderer, currentTab, wx + ww - 10 - mc.textRenderer.getWidth(currentTab), wy + 20, 0xFF77778A);

		// cards (clipped)
		c.enableScissor(cx - 1, top, cx + cw + 1, bottom);
		for (Card card : cards) {
			int x = card.x();
			int y = card.y() - scroll;
			if (y + card.h() < top || y > bottom) continue;
			boolean hover = card.contains(mx, my, scroll) && my >= top && my < bottom;
			boolean on = ModuleManager.isEnabled(card.mod().name());
			roundRect(c, x, y, card.w(), card.h(), 5, hover ? 0xFF1F1F2E : 0xFF171722);
			if (on) {
				c.fill(x + 1, y + 8, x + 3, y + CARD_H - 8, accent);
			}
			c.drawTextWithShadow(mc.textRenderer, card.mod().name(), x + 8, y + 7, 0xFFFFFFFF);
			if (card.mod().danger()) {
				int tx = x + 8 + mc.textRenderer.getWidth(card.mod().name()) + 4;
				roundRect(c, tx, y + 5, 38, 11, 3, 0xFFB02A2A);
				c.drawTextWithShadow(mc.textRenderer, "DANGER", tx + 3, y + 7, 0xFFFFFFFF);
			}
			String desc = mc.textRenderer.trimToWidth(card.mod().desc(), card.w() - 20);
			c.drawTextWithShadow(mc.textRenderer, desc, x + 8, y + 19, 0xFF77778A);

			float target = on ? 1f : 0f;
			float cur = ANIM.getOrDefault(card.mod().name(), target);
			cur += (target - cur) * 0.3f;
			ANIM.put(card.mod().name(), cur);
			drawSwitch(c, x + card.w() - 28, y + 7, cur, accent);

			if (!card.settings().isEmpty()) {
				c.drawTextWithShadow(mc.textRenderer, card.expanded() ? "v" : ">", x + card.w() - 12, y + CARD_H - 13, 0xFF8888A0);
			}
			if (card.expanded()) {
				c.fill(x + 6, y + CARD_H, x + card.w() - 6, y + CARD_H + 1, 0xFF2A2A3C);
				for (int i = 0; i < card.settings().size(); i++) {
					int ry = y + CARD_H + 4 + i * SROW;
					boolean rowHover = mx >= x && mx < x + card.w() && my >= ry && my < ry + SROW && my >= top && my < bottom;
					if (rowHover) {
						roundRect(c, x + 4, ry, card.w() - 8, SROW, 3, 0xFF22222F);
					}
					String label = mc.textRenderer.trimToWidth(card.settings().get(i).label(), card.w() - 24);
					c.drawTextWithShadow(mc.textRenderer, label, x + 10, ry + 3, 0xFFCCCCDD);
				}
			}
		}
		c.disableScissor();

		if (cards.isEmpty()) {
			String msg = "No modules found";
			c.drawTextWithShadow(mc.textRenderer, msg, cx + (cw - mc.textRenderer.getWidth(msg)) / 2, top + 30, 0xFF666678);
		}

		// accent color dots
		int dotsX = cx + cw / 2 - (Theme.COLORS.length * 12) / 2;
		for (int i = 0; i < Theme.COLORS.length; i++) {
			int dx = dotsX + i * 12;
			int dy = wy + wh - 14;
			if (i == Theme.index()) {
				roundRect(c, dx - 1, dy - 1, 12, 12, 6, 0xFFFFFFFF);
			}
			roundRect(c, dx, dy, 10, 10, 5, 0xFF000000 | Theme.COLORS[i]);
		}
	}
}
