package com.valerian.mixin;

import com.valerian.FriendManager;
import com.valerian.ModuleManager;
import com.valerian.SkinManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
	/** You and your friends wear the skin of the account set in SkinProtect. */
	@Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
	private void valerian$skinProtect(CallbackInfoReturnable<SkinTextures> cir) {
		if (!ModuleManager.isEnabled("SkinProtect")) return;
		SkinTextures custom = SkinManager.get();
		if (custom == null) return;
		AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
		MinecraftClient mc = MinecraftClient.getInstance();
		boolean isMe = mc.player != null && self.getUuid().equals(mc.player.getUuid());
		boolean friend = ModuleManager.isEnabled("Friends") && FriendManager.isFriend(self.getName().getString());
		if (isMe || friend) {
			cir.setReturnValue(custom);
		}
	}
}
