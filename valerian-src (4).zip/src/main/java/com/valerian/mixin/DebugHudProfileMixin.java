package com.valerian.mixin;

import com.valerian.ModuleManager;
import net.minecraft.client.gui.hud.debug.DebugHudEntries;
import net.minecraft.client.gui.hud.debug.DebugHudEntryVisibility;
import net.minecraft.client.gui.hud.debug.DebugHudProfile;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Turns the vanilla entity hitbox display (F3+B) on while the Hitbox module is enabled. */
@Mixin(DebugHudProfile.class)
public abstract class DebugHudProfileMixin {
	@Inject(method = "isEntryVisible", at = @At("HEAD"), cancellable = true)
	private void valerian$hitboxVisible(Identifier entryId, CallbackInfoReturnable<Boolean> cir) {
		if (DebugHudEntries.ENTITY_HITBOXES.equals(entryId) && ModuleManager.isEnabled("Hitbox")) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "getVisibility", at = @At("HEAD"), cancellable = true)
	private void valerian$hitboxVisibility(Identifier entryId, CallbackInfoReturnable<DebugHudEntryVisibility> cir) {
		if (DebugHudEntries.ENTITY_HITBOXES.equals(entryId) && ModuleManager.isEnabled("Hitbox")) {
			cir.setReturnValue(DebugHudEntryVisibility.ALWAYS_ON);
		}
	}
}
