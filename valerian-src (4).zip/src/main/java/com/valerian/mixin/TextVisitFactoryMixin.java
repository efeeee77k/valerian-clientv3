package com.valerian.mixin;

import com.valerian.NameProtect;
import net.minecraft.text.TextVisitFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(TextVisitFactory.class)
public abstract class TextVisitFactoryMixin {
	/** Every string drawn or measured goes through here, so the real name is swapped out everywhere. */
	@ModifyVariable(
		method = "visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
		at = @At("HEAD"),
		argsOnly = true
	)
	private static String valerian$protectName(String text) {
		return NameProtect.apply(text);
	}
}
