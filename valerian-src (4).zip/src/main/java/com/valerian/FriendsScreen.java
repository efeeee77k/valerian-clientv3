package com.valerian;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class FriendsScreen extends Screen {
	private TextFieldWidget input;

	public FriendsScreen() {
		super(Text.literal("Friends"));
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y0 = this.height / 2 - 100;

		input = new TextFieldWidget(this.textRenderer, cx - 110, y0, 150, 20, Text.literal("Name"));
		input.setMaxLength(32);
		addDrawableChild(input);

		addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> {
			FriendManager.add(input.getText());
			MinecraftClient.getInstance().setScreen(new FriendsScreen());
		}).dimensions(cx + 45, y0, 65, 20).build());

		List<String> friends = FriendManager.list();
		for (int i = 0; i < friends.size() && i < 8; i++) {
			final String name = friends.get(i);
			addDrawableChild(ButtonWidget.builder(Text.literal("Remove: " + name), b -> {
				FriendManager.remove(name);
				MinecraftClient.getInstance().setScreen(new FriendsScreen());
			}).dimensions(cx - 110, y0 + 28 + i * 24, 220, 20).build());
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx - 40, y0 + 28 + 8 * 24 + 4, 80, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Friends"),
			this.width / 2, this.height / 2 - 118, 0xFFB388FF);
		if (FriendManager.list().isEmpty()) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("No friends yet. Type a name and press Add."),
				this.width / 2, this.height / 2 - 60, 0xFF888888);
		}
	}
}
