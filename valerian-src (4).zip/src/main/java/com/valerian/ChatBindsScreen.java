package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ChatBindsScreen extends Screen {
	private int listening;

	public ChatBindsScreen(int listening) {
		super(Text.literal("Chat Binds"));
		this.listening = listening;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y0 = this.height / 2 - 85;

		for (int i = 0; i < ChatBinds.SLOTS; i++) {
			final int slot = i;
			String keyText = listening == slot ? "Press a key..." : "Key: " + ChatBinds.keyName(ChatBinds.getKey(slot));
			addDrawableChild(ButtonWidget.builder(Text.literal(keyText), b ->
				MinecraftClient.getInstance().setScreen(new ChatBindsScreen(slot))
			).dimensions(cx - 170, y0 + i * 26, 100, 20).build());

			TextFieldWidget tf = new TextFieldWidget(this.textRenderer, cx - 65, y0 + i * 26, 235, 20, Text.literal("Message"));
			tf.setMaxLength(100);
			tf.setText(ChatBinds.getMsg(slot));
			tf.setChangedListener(s -> ChatBinds.setMsg(slot, s));
			addDrawableChild(tf);
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx - 40, y0 + ChatBinds.SLOTS * 26 + 6, 80, 20).build());
	}

	@Override
	public void tick() {
		super.tick();
		if (listening < 0) return;
		long handle = MinecraftClient.getInstance().getWindow().getHandle();
		for (int k = 32; k <= 348; k++) {
			if (GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS) {
				if (k != GLFW.GLFW_KEY_ESCAPE) {
					ChatBinds.setKey(listening, k);
				}
				MinecraftClient.getInstance().setScreen(new ChatBindsScreen(-1));
				return;
			}
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Chat Binds"),
			this.width / 2, this.height / 2 - 108, 0xFFB388FF);
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Key + message (start with / for a command)"),
			this.width / 2, this.height / 2 + 82, 0xFF888888);
	}
}
