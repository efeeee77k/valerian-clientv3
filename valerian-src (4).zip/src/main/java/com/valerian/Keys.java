package com.valerian;

import org.lwjgl.glfw.GLFW;

public final class Keys {
	public static final int MENU_DEFAULT = GLFW.GLFW_KEY_RIGHT_SHIFT;

	private Keys() {}

	public static int get(String id, int def) {
		return Config.getInt("key." + id, def);
	}

	public static void set(String id, int key) {
		Config.set("key." + id, String.valueOf(key));
		Config.save();
	}

	public static int menu() {
		int k = get("menu", MENU_DEFAULT);
		return k == 0 ? MENU_DEFAULT : k;
	}
}
