package com.valerian;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** The cosmetics lobby: pick a slot, pick an item, wear it and see it on your player. */
public class CosmeticsScreen extends Screen {
	private final Cosmetics.Slot slot;
	private final String selected;

	public CosmeticsScreen(Cosmetics.Slot slot, String selected) {
		super(Text.literal("Cosmetics"));
		this.slot = slot;
		this.selected = selected;
	}

	@Override
	protected void init() {
		int x0 = this.width / 2 - 150;
		int y0 = this.height / 2 - 90;

		addDrawableChild(ButtonWidget.builder(Text.literal(slot == Cosmetics.Slot.HEAD ? "> Head" : "Head"), b ->
			MinecraftClient.getInstance().setScreen(new CosmeticsScreen(Cosmetics.Slot.HEAD, null))
		).dimensions(x0, y0, 60, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal(slot == Cosmetics.Slot.BACK ? "> Back" : "Back"), b ->
			MinecraftClient.getInstance().setScreen(new CosmeticsScreen(Cosmetics.Slot.BACK, null))
		).dimensions(x0, y0 + 24, 60, 20).build());
		ButtonWidget body = ButtonWidget.builder(Text.literal("Body *"), b -> { }).dimensions(x0, y0 + 48, 60, 20).build();
		body.active = false;
		addDrawableChild(body);

		String worn = Cosmetics.equipped(slot);
		List<Cosmetics.Item> items = Cosmetics.forSlot(slot);
		for (int i = 0; i < items.size() && i < 6; i++) {
			final Cosmetics.Item it = items.get(i);
			String label = (it.id().equals(selected) ? "> " : "") + it.name() + (it.id().equals(worn) ? " [on]" : "");
			addDrawableChild(ButtonWidget.builder(Text.literal(label), b ->
				MinecraftClient.getInstance().setScreen(new CosmeticsScreen(slot, it.id()))
			).dimensions(x0 + 68, y0 + i * 24, 110, 20).build());
		}

		if (selected != null) {
			final boolean isWorn = selected.equals(worn);
			addDrawableChild(ButtonWidget.builder(Text.literal(isWorn ? "Take off" : "Wear"), b -> {
				Cosmetics.equip(slot, isWorn ? "none" : selected);
				MinecraftClient.getInstance().setScreen(new CosmeticsScreen(slot, selected));
			}).dimensions(x0 + 68, y0 + 150, 110, 20).build());
		}
		addDrawableChild(ButtonWidget.builder(Text.literal("Back to menu"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(x0, y0 + 150, 60, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		MinecraftClient mc = MinecraftClient.getInstance();
		int x0 = this.width / 2 - 150;
		int y0 = this.height / 2 - 90;
		int px1 = x0 + 190;
		int py1 = y0;
		int px2 = x0 + 300;
		int py2 = y0 + 146;
		context.fill(px1, py1, px2, py2, 0xAA101018);
		if (mc.player != null) {
			InventoryScreen.drawEntity(context, px1, py1, px2, py2, 55, 0.0625f, (float) mouseX, (float) mouseY, mc.player);
		}
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Cosmetics"),
			this.width / 2, y0 - 16, 0xFFB388FF);
		if (!ModuleManager.isEnabled("Cosmetics")) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Cosmetics module is OFF"),
				this.width / 2, y0 + 176, 0xFFFF5555);
		}
	}
}
