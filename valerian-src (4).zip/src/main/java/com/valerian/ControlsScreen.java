package com.valerian;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Assign keys: the menu key and a toggle key for every module. */
public class ControlsScreen extends Screen {
	private record Entry(String id, String label, int def) {}

	private final int listening;

	public ControlsScreen(int listening) {
		super(Text.literal("Controls"));
		this.listening = listening;
	}

	private static List<Entry> entries() {
		List<Entry> out = new ArrayList<>();
		out.add(new Entry("menu", "Menu", Keys.MENU_DEFAULT));
		for (ModuleManager.Mod m : ModuleManager.ALL) {
			if (m.category().equals("HUDItem")) continue;
			out.add(new Entry("mod." + m.name(), m.name(), 0));
		}
		return out;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y0 = this.height / 2 - 92;
		List<Entry> list = entries();
		for (int i = 0; i < list.size() && i < 12; i++) {
			final int idx = i;
			Entry e = list.get(i);
			String keyText = listening == i ? "press a key..." : ChatBinds.keyName(Keys.get(e.id(), e.def()));
			addDrawableChild(ButtonWidget.builder(Text.literal(e.label() + ": " + keyText), b ->
				MinecraftClient.getInstance().setScreen(new ControlsScreen(idx))
			).dimensions(cx - 155 + (i % 2) * 160, y0 + (i / 2) * 24, 150, 20).build());
		}
		addDrawableChild(ButtonWidget.builder(Text.literal("Back to menu"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx - 50, y0 + 6 * 24 + 8, 100, 20).build());
	}

	@Override
	public void tick() {
		super.tick();
		if (listening < 0) return;
		List<Entry> list = entries();
		if (listening >= list.size()) return;
		Entry e = list.get(listening);
		long handle = MinecraftClient.getInstance().getWindow().getHandle();
		for (int k = 32; k <= 348; k++) {
			if (GLFW.glfwGetKey(handle, k) != GLFW.GLFW_PRESS) continue;
			if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) {
				Keys.set(e.id(), e.def());
			} else if (k != GLFW.GLFW_KEY_ESCAPE) {
				Keys.set(e.id(), k);
			}
			MinecraftClient.getInstance().setScreen(new ControlsScreen(-1));
			return;
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Controls"),
			this.width / 2, this.height / 2 - 112, Theme.accent());
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Click a button, then press a key. Backspace clears it."),
			this.width / 2, this.height / 2 + 82, 0xFF888888);
	}
}
