package com.valerian;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

public final class Config {
	private static final Properties P = new Properties();

	static {
		load();
	}

	private Config() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("valerian.properties");
	}

	public static String get(String key, String def) {
		return P.getProperty(key, def);
	}

	public static boolean getBool(String key, boolean def) {
		String v = P.getProperty(key);
		return v == null ? def : Boolean.parseBoolean(v);
	}

	public static int getInt(String key, int def) {
		String v = P.getProperty(key);
		if (v == null) return def;
		try {
			return Integer.parseInt(v.trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}

	public static void set(String key, String value) {
		P.setProperty(key, value);
	}

	public static void remove(String key) {
		P.remove(key);
	}

	private static void load() {
		Path p = file();
		if (!Files.exists(p)) return;
		try (InputStream in = Files.newInputStream(p)) {
			P.load(in);
		} catch (IOException e) {
			ValerianClient.LOGGER.warn("Could not load config", e);
		}
	}

	public static void save() {
		try (OutputStream out = Files.newOutputStream(file())) {
			P.store(out, "Valerian Client");
		} catch (IOException e) {
			ValerianClient.LOGGER.warn("Could not save config", e);
		}
	}
}
