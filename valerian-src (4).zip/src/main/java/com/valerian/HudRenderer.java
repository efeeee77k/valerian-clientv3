package com.valerian;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

public final class HudRenderer {
	public abstract static class Element {
		public final String name;
		public final int defX;
		public final int defY;
		public int w = 60;
		public int h = 14;

		Element(String name, int defX, int defY) {
			this.name = name;
			this.defX = defX;
			this.defY = defY;
		}

		public int getX() {
			return Config.getInt("hud." + name + ".x", defX);
		}

		public int getY() {
			return Config.getInt("hud." + name + ".y", defY);
		}

		public void setPos(int x, int y) {
			Config.set("hud." + name + ".x", String.valueOf(x));
			Config.set("hud." + name + ".y", String.valueOf(y));
		}

		public void resetPos() {
			Config.remove("hud." + name + ".x");
			Config.remove("hud." + name + ".y");
		}

		/** Draws the element at x,y and updates w and h. */
		public abstract void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit);
	}

	public static final List<Element> ELEMENTS = new ArrayList<>();

	private static final int BG = 0x99101018;
		private static final int WHITE = 0xFFFFFFFF;

	private static void box(DrawContext c, int x, int y, int w, int h) {
		c.fill(x, y, x + w, y + h, BG);
		c.fill(x, y, x + 2, y + h, Theme.accent());
	}

	private static void textBox(Element e, DrawContext c, MinecraftClient mc, int x, int y, List<String> lines, List<Integer> colors) {
		int maxW = 0;
		for (String s : lines) maxW = Math.max(maxW, mc.textRenderer.getWidth(s));
		e.w = maxW + 10;
		e.h = lines.size() * 11 + 4;
		box(c, x, y, e.w, e.h);
		for (int i = 0; i < lines.size(); i++) {
			c.drawTextWithShadow(mc.textRenderer, lines.get(i), x + 6, y + 3 + i * 11, colors.get(i));
		}
	}

	private static void single(Element e, DrawContext c, MinecraftClient mc, int x, int y, String text) {
		List<String> l = new ArrayList<>();
		l.add(text);
		List<Integer> col = new ArrayList<>();
		col.add(WHITE);
		textBox(e, c, mc, x, y, l, col);
	}

	private static String time(int seconds) {
		return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
	}

	private static void keyBox(DrawContext c, MinecraftClient mc, int x, int y, int w, int h, String label, boolean down) {
		c.fill(x, y, x + w, y + h, down ? 0xCCB388FF : BG);
		int tw = mc.textRenderer.getWidth(label);
		c.drawTextWithShadow(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, WHITE);
	}

	static {
		ELEMENTS.add(new Element("FPS", 6, 6) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				single(this, c, mc, x, y, "FPS: " + mc.getCurrentFps());
			}
		});
		ELEMENTS.add(new Element("XYZ", 6, 24) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				String s = "XYZ: 0 0 0";
				if (mc.player != null) {
					s = String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
				}
				single(this, c, mc, x, y, s);
			}
		});
		ELEMENTS.add(new Element("Ping", 6, 42) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				int ping = 0;
				if (mc.player != null && mc.getNetworkHandler() != null) {
					PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
					if (entry != null) ping = entry.getLatency();
				}
				single(this, c, mc, x, y, "Ping: " + ping + "ms");
			}
		});
		ELEMENTS.add(new Element("Direction", 6, 60) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				String s = "Facing: -";
				if (mc.player != null) {
					s = "Facing: " + mc.player.getHorizontalFacing().asString().toUpperCase();
				}
				single(this, c, mc, x, y, s);
			}
		});
		ELEMENTS.add(new Element("Armor", 6, 80) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
				String[] names = {"Helmet", "Chest", "Legs", "Boots"};
				List<String> lines = new ArrayList<>();
				List<Integer> colors = new ArrayList<>();
				for (int i = 0; i < slots.length; i++) {
					ItemStack stack = mc.player != null ? mc.player.getEquippedStack(slots[i]) : ItemStack.EMPTY;
					if (stack.isEmpty() || !stack.isDamageable()) {
						lines.add(names[i] + ": -");
						colors.add(0xFF888888);
					} else {
						int max = stack.getMaxDamage();
						int pct = Math.round((max - stack.getDamage()) * 100f / max);
						lines.add(names[i] + ": " + pct + "%");
						colors.add(pct > 50 ? 0xFF66FF66 : (pct > 20 ? 0xFFFFDD55 : 0xFFFF5555));
					}
				}
				textBox(this, c, mc, x, y, lines, colors);
			}
		});
		ELEMENTS.add(new Element("Keystrokes", 6, 140) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				int s = 18;
				int g = 2;
				w = 3 * s + 2 * g;
				h = 2 * (s + g) + 12;
				keyBox(c, mc, x + s + g, y, s, s, "W", mc.options.forwardKey.isPressed());
				keyBox(c, mc, x, y + s + g, s, s, "A", mc.options.leftKey.isPressed());
				keyBox(c, mc, x + s + g, y + s + g, s, s, "S", mc.options.backKey.isPressed());
				keyBox(c, mc, x + 2 * (s + g), y + s + g, s, s, "D", mc.options.rightKey.isPressed());
				keyBox(c, mc, x, y + 2 * (s + g), w, 12, "SPACE", mc.options.jumpKey.isPressed());
			}
		});
		ELEMENTS.add(new Element("Potion", 110, 6) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				List<String> lines = new ArrayList<>();
				List<Integer> colors = new ArrayList<>();
				if (mc.player != null) {
					for (StatusEffectInstance e : mc.player.getStatusEffects()) {
						String n = e.getEffectType().value().getName().getString();
						String t = e.getDuration() < 0 ? "inf" : time(e.getDuration() / 20);
						lines.add(n + " " + (e.getAmplifier() + 1) + " - " + t);
						colors.add(WHITE);
					}
				}
				if (lines.isEmpty()) {
					if (!edit) return;
					lines.add("Speed 2 - 0:30");
					colors.add(0xFF888888);
				}
				textBox(this, c, mc, x, y, lines, colors);
			}
		});
		ELEMENTS.add(new Element("TargetHUD", 200, 100) {
			@Override
			public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean edit) {
				String name = "Target";
				float hp = 20f;
				float max = 20f;
				Entity t = mc.targetedEntity;
				if (t instanceof LivingEntity le) {
					name = NameProtect.apply(le.getName().getString());
					hp = le.getHealth();
					max = Math.max(1f, le.getMaxHealth());
				} else if (!edit) {
					return;
				}
				w = 100;
				h = 28;
				box(c, x, y, w, h);
				int nameColor = ModuleManager.isEnabled("Friends") && FriendManager.isFriend(name) ? 0xFF66FF66 : WHITE;
				c.drawTextWithShadow(mc.textRenderer, name, x + 6, y + 3, nameColor);
				c.fill(x + 6, y + 16, x + 94, y + 22, 0xFF333344);
				int fill = Math.round(88 * Math.min(1f, hp / max));
				c.fill(x + 6, y + 16, x + 6 + fill, y + 22, 0xFFFF5555);
				String hs = Math.round(hp * 10f) / 10f + " HP";
				c.drawTextWithShadow(mc.textRenderer, hs, x + 60, y + 3, 0xFFCCCCCC);
			}
		});
	}

	private HudRenderer() {}

	public static void register() {
		HudRenderCallback.EVENT.register((context, tickCounter) -> renderAll(context));
	}

	private static void renderAll(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;
		if (!ModuleManager.isEnabled("HUD")) return;
		if (mc.currentScreen instanceof HudEditScreen) return;
		for (Element e : ELEMENTS) {
			if (ModuleManager.isEnabled(e.name)) {
				e.draw(context, mc, e.getX(), e.getY(), false);
			}
		}
	}
}
