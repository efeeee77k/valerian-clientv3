package com.valerian;

import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class TextInputScreen extends Screen {
	private final String prompt;
	private final String initial;
	private final Consumer<String> onSave;
	private TextFieldWidget field;

	public TextInputScreen(String prompt, String initial, Consumer<String> onSave) {
		super(Text.literal(prompt));
		this.prompt = prompt;
		this.initial = initial == null ? "" : initial;
		this.onSave = onSave;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int cy = this.height / 2;
		field = new TextFieldWidget(this.textRenderer, cx - 100, cy - 10, 200, 20, Text.literal(prompt));
		field.setMaxLength(32);
		field.setText(initial);
		addDrawableChild(field);
		this.setInitialFocus(field);

		addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> {
			onSave.accept(field.getText().trim());
			MinecraftClient.getInstance().setScreen(new ValerianScreen());
		}).dimensions(cx - 100, cy + 20, 95, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(cx + 5, cy + 20, 95, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(prompt),
			this.width / 2, this.height / 2 - 30, 0xFFB388FF);
	}
}
