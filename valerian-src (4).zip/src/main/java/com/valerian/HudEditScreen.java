package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class HudEditScreen extends Screen {
	private HudRenderer.Element dragging = null;
	private int grabX = 0;
	private int grabY = 0;
	private boolean wasDown = true;

	public HudEditScreen() {
		super(Text.literal("HUD Edit"));
	}

	@Override
	protected void init() {
		addDrawableChild(ButtonWidget.builder(Text.literal("Reset"), b -> {
			for (HudRenderer.Element e : HudRenderer.ELEMENTS) e.resetPos();
			Config.save();
		}).dimensions(this.width / 2 - 85, this.height - 30, 80, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b ->
			MinecraftClient.getInstance().setScreen(new ValerianScreen())
		).dimensions(this.width / 2 + 5, this.height - 30, 80, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		MinecraftClient mc = MinecraftClient.getInstance();
		long handle = mc.getWindow().getHandle();
		boolean down = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

		if (down && !wasDown) {
			for (int i = HudRenderer.ELEMENTS.size() - 1; i >= 0; i--) {
				HudRenderer.Element e = HudRenderer.ELEMENTS.get(i);
				if (!ModuleManager.isEnabled(e.name)) continue;
				int x = e.getX();
				int y = e.getY();
				if (mouseX >= x && mouseX <= x + e.w && mouseY >= y && mouseY <= y + e.h) {
					dragging = e;
					grabX = mouseX - x;
					grabY = mouseY - y;
					break;
				}
			}
		}
		if (!down && dragging != null) {
			Config.save();
			dragging = null;
		}
		if (down && dragging != null) {
			int nx = Math.max(0, Math.min(this.width - dragging.w, mouseX - grabX));
			int ny = Math.max(0, Math.min(this.height - dragging.h, mouseY - grabY));
			dragging.setPos(nx, ny);
		}
		wasDown = down;

		for (HudRenderer.Element e : HudRenderer.ELEMENTS) {
			if (!ModuleManager.isEnabled(e.name)) continue;
			int x = e.getX();
			int y = e.getY();
			e.draw(context, mc, x, y, true);
			int col = e == dragging ? 0xFFFFFFFF : 0xFFB388FF;
			context.fill(x - 1, y - 1, x + e.w + 1, y, col);
			context.fill(x - 1, y + e.h, x + e.w + 1, y + e.h + 1, col);
			context.fill(x - 1, y, x, y + e.h, col);
			context.fill(x + e.w, y, x + e.w + 1, y + e.h, col);
		}
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Drag HUD elements with the mouse"),
			this.width / 2, 8, 0xFFB388FF);
	}
}
