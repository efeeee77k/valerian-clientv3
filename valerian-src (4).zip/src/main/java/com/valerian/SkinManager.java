package com.valerian;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.Proxy;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.PlayerSkinTextureDownloader;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Identifier;

/** Loads the skin of a premium account by name (like SkinsRestorer) and keeps it ready for rendering. */
public final class SkinManager {
	private static volatile SkinTextures current = null;
	private static volatile String status = "No account set";

	private SkinManager() {}

	public static SkinTextures get() {
		return current;
	}

	public static String status() {
		return status;
	}

	public static String account() {
		return Config.get("skin.account", "");
	}

	public static void init() {
		String n = account();
		if (!n.isBlank()) load(n);
	}

	public static void setAccount(String name) {
		String n = name == null ? "" : name.trim();
		Config.set("skin.account", n);
		Config.save();
		load(n);
	}

	public static void reload() {
		load(account());
	}

	private static String fetch(HttpClient http, String url) throws Exception {
		HttpRequest req = HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "ValerianClient").build();
		HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
		if (res.statusCode() != 200) {
			throw new IllegalStateException("HTTP " + res.statusCode());
		}
		return res.body();
	}

	private static void load(String name) {
		if (name == null || name.isBlank()) {
			current = null;
			status = "No account set";
			return;
		}
		final String n = name.trim();
		status = "Loading " + n + "...";
		CompletableFuture.runAsync(() -> {
			try {
				HttpClient http = HttpClient.newHttpClient();
				String idBody;
				try {
					idBody = fetch(http, "https://api.mojang.com/users/profiles/minecraft/" + URLEncoder.encode(n, StandardCharsets.UTF_8));
				} catch (IllegalStateException e) {
					status = "Account not found: " + n;
					return;
				}
				String id = JsonParser.parseString(idBody).getAsJsonObject().get("id").getAsString();
				String profileBody = fetch(http, "https://sessionserver.mojang.com/session/minecraft/profile/" + id);
				JsonArray props = JsonParser.parseString(profileBody).getAsJsonObject().getAsJsonArray("properties");
				String value = null;
				for (JsonElement e : props) {
					JsonObject o = e.getAsJsonObject();
					if ("textures".equals(o.get("name").getAsString())) value = o.get("value").getAsString();
				}
				if (value == null) {
					status = "No skin data for " + n;
					return;
				}
				String json = new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
				JsonObject skin = JsonParser.parseString(json).getAsJsonObject().getAsJsonObject("textures").getAsJsonObject("SKIN");
				final String url = skin.get("url").getAsString();
				boolean slim = false;
				if (skin.has("metadata") && skin.getAsJsonObject("metadata").has("model")) {
					slim = "slim".equals(skin.getAsJsonObject("metadata").get("model").getAsString());
				}
				final boolean isSlim = slim;
				final String hash = url.substring(url.lastIndexOf('/') + 1).toLowerCase();
				MinecraftClient.getInstance().execute(() -> register(n, url, hash, isSlim));
			} catch (Exception e) {
				ValerianClient.LOGGER.warn("Skin load failed", e);
				status = "Failed (try Reload)";
			}
		});
	}

	private static void register(String name, String url, String hash, boolean slim) {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			Identifier id = Identifier.of("valerian", "skin/" + hash);
			Path path = FabricLoader.getInstance().getGameDir().resolve("valerian_skins").resolve(hash + ".png");
			Files.createDirectories(path.getParent());
			PlayerSkinTextureDownloader downloader = new PlayerSkinTextureDownloader(Proxy.NO_PROXY, mc.getTextureManager(), mc::execute);
			downloader.downloadAndRegisterTexture(id, path, url, true).thenAccept(asset -> {
				current = SkinTextures.create(asset, null, null, slim ? PlayerSkinType.SLIM : PlayerSkinType.WIDE);
				status = "Skin: " + name;
			}).exceptionally(ex -> {
				ValerianClient.LOGGER.warn("Skin download failed", ex);
				status = "Download failed";
				return null;
			});
		} catch (Exception e) {
			ValerianClient.LOGGER.warn("Skin register failed", e);
			status = "Failed (try Reload)";
		}
	}
}
