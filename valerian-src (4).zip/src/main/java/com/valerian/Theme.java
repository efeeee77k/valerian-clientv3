package com.valerian;

public final class Theme {
	public static final int[] COLORS = {0x7B5CF0, 0x4F9BFF, 0xF05CB0, 0x4FD08A, 0xF0A24F, 0xE6E6F0};

	private Theme() {}

	public static int index() {
		int i = Config.getInt("ui.accent", 0);
		return i < 0 || i >= COLORS.length ? 0 : i;
	}

	public static int accent() {
		return 0xFF000000 | COLORS[index()];
	}

	public static void set(int i) {
		Config.set("ui.accent", String.valueOf(i));
		Config.save();
	}

	public static int blend(int a, int b, float t) {
		int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
		int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
		int r = Math.round(ar + (br - ar) * t);
		int g = Math.round(ag + (bg - ag) * t);
		int bl = Math.round(ab + (bb - ab) * t);
		return 0xFF000000 | (r << 16) | (g << 8) | bl;
	}
}
