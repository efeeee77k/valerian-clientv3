package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AxolotlEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.FoxEntity;
import net.minecraft.entity.passive.ParrotEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

/**
 * A client side pet that follows you. Only you can see it.
 * Ground pets walk, sit after 3 seconds of standing still and sleep after 3 more.
 */
public final class PetManager {
	public static final String[] TYPES = {"None", "Parrot", "Fox", "Bee", "Wolf", "Axolotl", "Cat"};

	private static Entity pet = null;
	private static String petType = "";
	private static ClientWorld petWorld = null;
	private static int tickCount = 0;

	private static double lastPx;
	private static double lastPy;
	private static double lastPz;
	private static float lastYaw;
	private static float lastPitch;
	private static int idleTicks = 0;

	private static float petYaw = 0f;
	private static int appliedStage = -1;
	private static int zTick = 0;
	private static String lastLabel = "";

	private PetManager() {}

	public static String selected() {
		String s = Config.get("pet.type", "None");
		for (String t : TYPES) {
			if (t.equals(s)) return s;
		}
		return "None";
	}

	public static void cycle(int dir) {
		int idx = 0;
		String cur = selected();
		for (int i = 0; i < TYPES.length; i++) {
			if (TYPES[i].equals(cur)) idx = i;
		}
		idx = (idx + dir + TYPES.length) % TYPES.length;
		Config.set("pet.type", TYPES[idx]);
		Config.save();
	}

	private static void remove() {
		if (pet != null) {
			pet.discard();
			pet = null;
		}
		petType = "";
		petWorld = null;
		appliedStage = -1;
		lastLabel = "";
		zTick = 0;
	}

	public static void tick(MinecraftClient mc) {
		String want = ModuleManager.isEnabled("Pets") ? selected() : "None";
		if (mc.player == null || mc.world == null || want.equals("None")) {
			remove();
			return;
		}
		if (pet == null || !want.equals(petType) || petWorld != mc.world || pet.isRemoved()) {
			remove();
			spawn(mc, want);
		}
		updateIdle(mc.player);
		if (pet != null) follow(mc.player);
	}

	private static void updateIdle(ClientPlayerEntity p) {
		double dx = p.getX() - lastPx;
		double dy = p.getY() - lastPy;
		double dz = p.getZ() - lastPz;
		boolean moved = dx * dx + dy * dy + dz * dz > 1.0E-4
			|| Math.abs(p.getYaw() - lastYaw) > 0.5f
			|| Math.abs(p.getPitch() - lastPitch) > 0.5f;
		lastPx = p.getX();
		lastPy = p.getY();
		lastPz = p.getZ();
		lastYaw = p.getYaw();
		lastPitch = p.getPitch();
		idleTicks = moved ? 0 : idleTicks + 1;
	}

	private static void spawn(MinecraftClient mc, String type) {
		ClientWorld world = mc.world;
		Entity e = switch (type) {
			case "Parrot" -> new ParrotEntity(EntityType.PARROT, world);
			case "Fox" -> new FoxEntity(EntityType.FOX, world);
			case "Bee" -> new BeeEntity(EntityType.BEE, world);
			case "Wolf" -> new WolfEntity(EntityType.WOLF, world);
			case "Axolotl" -> new AxolotlEntity(EntityType.AXOLOTL, world);
			case "Cat" -> new CatEntity(EntityType.CAT, world);
			default -> null;
		};
		if (e == null) return;
		e.setId(-777000 - type.length());
		e.setNoGravity(true);
		e.noClip = true;
		e.setPosition(mc.player.getX(), mc.player.getY(), mc.player.getZ());
		world.addEntity(e);
		pet = e;
		petType = type;
		petWorld = world;
		petYaw = mc.player.getYaw();
		appliedStage = -1;
	}

	private static void follow(ClientPlayerEntity p) {
		boolean flying = petType.equals("Parrot") || petType.equals("Bee");
		int stage = flying ? 0 : (idleTicks >= 120 ? 2 : (idleTicks >= 60 ? 1 : 0));

		double ox = pet.getX();
		double oz = pet.getZ();
		double yaw = Math.toRadians(p.getYaw());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double rx = -Math.cos(yaw);
		double rz = -Math.sin(yaw);
		double tx = p.getX() + rx * 0.9 - fx * 0.9;
		double tz = p.getZ() + rz * 0.9 - fz * 0.9;
		double ty = p.getY() + (flying ? 1.5 + Math.sin(tickCount * 0.12) * 0.15 : 0.0);
		tickCount++;

		if (stage == 0) {
			double dx = tx - pet.getX();
			double dy = ty - pet.getY();
			double dz = tz - pet.getZ();
			if (dx * dx + dy * dy + dz * dz > 36.0) {
				pet.setPosition(tx, ty, tz);
			} else {
				pet.setPosition(pet.getX() + dx * 0.2, pet.getY() + dy * 0.2, pet.getZ() + dz * 0.2);
			}
		}

		double mdx = pet.getX() - ox;
		double mdz = pet.getZ() - oz;
		double moved = Math.sqrt(mdx * mdx + mdz * mdz);
		if (moved > 0.02) {
			float moveYaw = (float) Math.toDegrees(Math.atan2(-mdx, mdz));
			petYaw += MathHelper.wrapDegrees(moveYaw - petYaw) * 0.3f;
		} else if (stage == 0) {
			petYaw += MathHelper.wrapDegrees(p.getYaw() - petYaw) * 0.05f;
		}

		pet.setYaw(petYaw);
		pet.setPitch(0f);
		pet.setOnGround(!flying);
		if (pet instanceof LivingEntity le) {
			le.setBodyYaw(petYaw);
			le.setHeadYaw(petYaw);
			le.limbAnimator.updateLimbs(Math.min((float) moved * 4f, 1f), 0.4f, 1.0f);
			applyPose(le, stage);
		}
		updateSleepLabel(stage);
	}

	private static void applyPose(LivingEntity le, int stage) {
		if (stage == appliedStage) return;
		appliedStage = stage;
		if (le instanceof WolfEntity w) {
			w.setInSittingPose(stage >= 1);
		} else if (le instanceof CatEntity c) {
			c.setInSittingPose(stage == 1);
			c.setInSleepingPose(stage == 2);
		} else if (le instanceof FoxEntity f) {
			f.setSitting(stage >= 1);
		} else if (le instanceof AxolotlEntity a) {
			a.setPlayingDead(stage == 2);
		}
	}

	private static void updateSleepLabel(int stage) {
		if (stage == 2) {
			zTick++;
			int phase = (zTick / 15) % 3;
			String s = phase == 0 ? "z" : (phase == 1 ? "z Z" : "z Z Z");
			if (!s.equals(lastLabel)) {
				lastLabel = s;
				pet.setCustomName(Text.literal(s).formatted(Formatting.AQUA));
				pet.setCustomNameVisible(true);
			}
		} else if (!lastLabel.isEmpty()) {
			lastLabel = "";
			zTick = 0;
			pet.setCustomName(null);
			pet.setCustomNameVisible(false);
		}
	}
}
