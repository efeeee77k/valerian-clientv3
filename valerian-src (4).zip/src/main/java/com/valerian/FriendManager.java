package com.valerian;

import java.util.ArrayList;
import java.util.List;

public final class FriendManager {
	private FriendManager() {}

	public static List<String> list() {
		List<String> out = new ArrayList<>();
		String raw = Config.get("friends", "");
		for (String s : raw.split(",")) {
			String t = s.trim();
			if (!t.isEmpty()) out.add(t);
		}
		return out;
	}

	private static void store(List<String> names) {
		Config.set("friends", String.join(",", names));
		Config.save();
	}

	public static boolean isFriend(String name) {
		for (String f : list()) {
			if (f.equalsIgnoreCase(name)) return true;
		}
		return false;
	}

	public static void add(String name) {
		String n = name.trim().replace(",", "");
		if (n.isEmpty() || isFriend(n)) return;
		List<String> l = list();
		l.add(n);
		store(l);
	}

	public static void remove(String name) {
		List<String> l = list();
		l.removeIf(f -> f.equalsIgnoreCase(name));
		store(l);
	}
}
