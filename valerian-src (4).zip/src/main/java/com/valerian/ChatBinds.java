package com.valerian;

import org.lwjgl.glfw.GLFW;

public final class ChatBinds {
	public static final int SLOTS = 5;

	private ChatBinds() {}

	public static int getKey(int slot) {
		return Config.getInt("bind." + slot + ".key", 0);
	}

	public static String getMsg(int slot) {
		return Config.get("bind." + slot + ".msg", "");
	}

	public static void setKey(int slot, int key) {
		Config.set("bind." + slot + ".key", String.valueOf(key));
		Config.save();
	}

	public static void setMsg(int slot, String msg) {
		Config.set("bind." + slot + ".msg", msg);
		Config.save();
	}

	public static String keyName(int key) {
		if (key == 0) return "NONE";
		if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
		if (key == GLFW.GLFW_KEY_ENTER) return "ENTER";
		if (key == GLFW.GLFW_KEY_TAB) return "TAB";
		if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "L-SHIFT";
		if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "R-SHIFT";
		if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "L-CTRL";
		if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "R-CTRL";
		if (key == GLFW.GLFW_KEY_LEFT_ALT) return "L-ALT";
		if (key == GLFW.GLFW_KEY_RIGHT_ALT) return "R-ALT";
		if (key == GLFW.GLFW_KEY_UP) return "UP";
		if (key == GLFW.GLFW_KEY_DOWN) return "DOWN";
		if (key == GLFW.GLFW_KEY_LEFT) return "LEFT";
		if (key == GLFW.GLFW_KEY_RIGHT) return "RIGHT";
		if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F12) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
		String n = GLFW.glfwGetKeyName(key, 0);
		return n != null ? n.toUpperCase() : "KEY " + key;
	}
}
