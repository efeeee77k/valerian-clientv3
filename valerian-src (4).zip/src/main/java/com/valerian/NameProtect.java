package com.valerian;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

public final class NameProtect {
	private static volatile String ownFake = Config.get("name.own", "Valerian");
	private static volatile String othersFake = Config.get("name.others", "");
	private static volatile String realName = "";
	private static volatile String[] others = new String[0];
	private static final Set<String> SEEN = new LinkedHashSet<>();

	private NameProtect() {}

	public static String ownFake() {
		return ownFake.isBlank() ? "Valerian" : ownFake;
	}

	public static String othersFake() {
		return othersFake;
	}

	public static void setOwn(String value) {
		ownFake = value == null ? "" : value.trim();
		Config.set("name.own", ownFake);
		Config.save();
	}

	public static void setOthers(String value) {
		othersFake = value == null ? "" : value.trim();
		Config.set("name.others", othersFake);
		Config.save();
	}

	/** Called about once a second from the client tick. */
	public static void refresh(MinecraftClient mc) {
		if (mc.player == null || mc.world == null) {
			realName = "";
			return;
		}
		realName = mc.player.getName().getString();
		for (PlayerEntity pl : mc.world.getPlayers()) {
			String n = pl.getName().getString();
			if (n.length() >= 3 && !n.equals(realName)) SEEN.add(n);
		}
		List<String> list = new ArrayList<>();
		for (String n : SEEN) {
			if (ModuleManager.isEnabled("Friends") && FriendManager.isFriend(n)) continue;
			list.add(n);
		}
		others = list.toArray(new String[0]);
	}

	public static String apply(String s) {
		if (s == null || s.length() < 3 || !ModuleManager.isEnabled("NameProtect")) return s;
		String r = s;
		String of = othersFake;
		if (!of.isEmpty()) {
			for (String n : others) {
				if (r.contains(n)) r = r.replace(n, of);
			}
		}
		String me = realName;
		if (!me.isEmpty() && r.contains(me)) {
			r = r.replace(me, ownFake());
		}
		return r;
	}

	public static Text apply(Text t) {
		String s = t.getString();
		String r = apply(s);
		return r.equals(s) ? t : Text.literal(r);
	}
}
