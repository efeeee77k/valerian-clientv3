package com.valerian;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/** Small hand built models. Units are pixels, y points down, the origin is the neck line. */
public final class CosmeticModels {
	private static final Map<String, ModelPart> CACHE = new HashMap<>();

	private CosmeticModels() {}

	public static ModelPart get(String id) {
		ModelPart cached = CACHE.get(id);
		if (cached != null) return cached;
		ModelPart built = build(id);
		if (built != null) CACHE.put(id, built);
		return built;
	}

	private static ModelPart build(String id) {
		return switch (id) {
			case "crown" -> crown();
			case "straw_hat" -> strawHat();
			case "devil_horns" -> horns();
			case "halo_gold", "halo_white" -> halo();
			case "demon_wings" -> wings(24f, 20f);
			case "angel_wings" -> wings(28f, 22f);
			default -> null;
		};
	}

	private static ModelPart finish(ModelData data, int w, int h) {
		return TexturedModelData.of(data, w, h).createModel().getChild("c");
	}

	private static ModelPart crown() {
		ModelData md = new ModelData();
		md.getRoot().addChild("c", ModelPartBuilder.create().uv(0, 0)
			.cuboid(-4.5f, -10f, -4.5f, 9f, 2f, 1f)
			.cuboid(-4.5f, -10f, 3.5f, 9f, 2f, 1f)
			.cuboid(-4.5f, -10f, -3.5f, 1f, 2f, 7f)
			.cuboid(3.5f, -10f, -3.5f, 1f, 2f, 7f)
			.cuboid(-4.5f, -12.5f, -4.5f, 1.5f, 2.5f, 1f)
			.cuboid(-0.75f, -13f, -4.5f, 1.5f, 3f, 1f)
			.cuboid(3f, -12.5f, -4.5f, 1.5f, 2.5f, 1f)
			.cuboid(-4.5f, -12.5f, 3.5f, 1.5f, 2.5f, 1f)
			.cuboid(-0.75f, -13f, 3.5f, 1.5f, 3f, 1f)
			.cuboid(3f, -12.5f, 3.5f, 1.5f, 2.5f, 1f),
			ModelTransform.NONE);
		return finish(md, 128, 64);
	}

	private static ModelPart strawHat() {
		ModelData md = new ModelData();
		md.getRoot().addChild("c", ModelPartBuilder.create().uv(0, 0)
			.cuboid(-8.5f, -9f, -8.5f, 17f, 1f, 17f)
			.cuboid(-6.5f, -10f, -6.5f, 13f, 1f, 13f)
			.cuboid(-4.5f, -11f, -4.5f, 9f, 1f, 9f)
			.cuboid(-3f, -12f, -3f, 6f, 1f, 6f)
			.cuboid(-1.5f, -13f, -1.5f, 3f, 1f, 3f)
			.cuboid(-0.5f, -14f, -0.5f, 1f, 1f, 1f),
			ModelTransform.NONE);
		return finish(md, 128, 64);
	}

	private static void horn(ModelPartData group, String prefix, float side) {
		float x = 2.4f * side;
		float y = -8f;
		float[] roll = {0.12f, 0.5f, 0.95f};
		float[] pitch = {0f, -0.2f, -0.35f};
		float[] len = {3f, 3f, 2.6f};
		float[] width = {2.6f, 2.0f, 1.4f};
		for (int i = 0; i < 3; i++) {
			float r = roll[i] * side;
			group.addChild(prefix + i, ModelPartBuilder.create().uv(0, 0)
				.cuboid(-width[i] / 2f, -len[i], -width[i] / 2f, width[i], len[i], width[i]),
				ModelTransform.of(x, y, -1f, pitch[i], 0f, r));
			x += (float) Math.sin(roll[i]) * len[i] * side;
			y -= (float) Math.cos(roll[i]) * len[i];
		}
	}

	private static ModelPart horns() {
		ModelData md = new ModelData();
		ModelPartData group = md.getRoot().addChild("c", ModelPartBuilder.create(), ModelTransform.NONE);
		horn(group, "r", 1f);
		horn(group, "l", -1f);
		return finish(md, 128, 64);
	}

	private static ModelPart halo() {
		ModelData md = new ModelData();
		ModelPartData group = md.getRoot().addChild("c", ModelPartBuilder.create(), ModelTransform.NONE);
		float radius = 6.6f;
		for (int i = 0; i < 16; i++) {
			float a = (float) (i * Math.PI * 2.0 / 16.0);
			group.addChild("s" + i, ModelPartBuilder.create().uv(0, 0).cuboid(-1.4f, -0.4f, -0.5f, 2.8f, 0.8f, 1.0f),
				ModelTransform.of((float) Math.sin(a) * radius, -13f, (float) Math.cos(a) * radius, 0f, a, 0f));
		}
		group.addChild("glow", ModelPartBuilder.create().uv(16, 0).cuboid(-8f, -13.5f, -8f, 16f, 1f, 16f), ModelTransform.NONE);
		return finish(md, 64, 32);
	}

	private static ModelPart wings(float w, float h) {
		ModelData md = new ModelData();
		ModelPartData group = md.getRoot().addChild("c", ModelPartBuilder.create(), ModelTransform.NONE);
		float top = -(h * 0.35f);
		group.addChild("r", ModelPartBuilder.create().uv(0, 0).cuboid(0f, top, 0f, w, h, 1f),
			ModelTransform.of(1.5f, 3f, 2.4f, 0f, -0.5f, 0f));
		group.addChild("l", ModelPartBuilder.create().mirrored().uv(0, 0).cuboid(-w, top, 0f, w, h, 1f),
			ModelTransform.of(-1.5f, 3f, 2.4f, 0f, 0.5f, 0f));
		return finish(md, 64, 32);
	}

	/** Flaps the wings. Other cosmetics have nothing to animate. */
	public static void animate(String id, ModelPart part) {
		double t = System.currentTimeMillis() / 1000.0;
		if (id.startsWith("halo")) {
			part.pivotY = (float) Math.sin(t * 2.0) * 0.5f;
			return;
		}
		if (!id.endsWith("_wings")) return;
		float flap = (float) Math.sin(t * 2.4) * 0.22f;
		part.getChild("r").yaw = -0.5f + flap;
		part.getChild("l").yaw = 0.5f - flap;
	}
}
