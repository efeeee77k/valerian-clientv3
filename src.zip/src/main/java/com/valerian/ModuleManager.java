package com.valerian;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

public final class ModuleManager {
	public record Mod(String name, String category, boolean implemented) {}

	public static final String[] CATEGORIES = {"HUD", "Visuals", "Player", "World", "Movement"};
	public static final List<Mod> ALL = new ArrayList<>();
	private static final Map<String, Boolean> STATE = new LinkedHashMap<>();

	private static void add(String category, String name, boolean implemented) {
		ALL.add(new Mod(name, category, implemented));
		STATE.put(name, true);
	}

	static {
		// HUD
		add("HUD", "SVisuals HUD", true);
		add("HUD", "Health Notify", true);
		add("HUD", "Module List", true);
		add("HUD", "Armor HP", true);
		add("HUD", "Animated TAB", false);
		add("HUD", "Screen Animations", false);
		add("HUD", "Better Chat", false);
		add("HUD", "Item Highlights", false);
		add("HUD", "Full TAB", false);
		// Visuals
		add("Visuals", "Mouse Particles", false);
		add("Visuals", "Clean View", false);
		add("Visuals", "Kill Effect", false);
		add("Visuals", "Uniform Skin", false);
		add("Visuals", "Free Look", false);
		add("Visuals", "Wave Cape", false);
		add("Visuals", "Tracers", false);
		add("Visuals", "Hit & Critical Sounds", false);
		add("Visuals", "Custom End Crystal", false);
		add("Visuals", "Combat Hearts", false);
		add("Visuals", "Friend Marker", false);
		add("Visuals", "Wings HD", false);
		add("Visuals", "Head Cosmetics", false);
		// Player
		add("Player", "Quick Pearl", false);
		add("Player", "Player Glow", false);
		add("Player", "Swing Animations", false);
		add("Player", "Streamer Mode", false);
		add("Player", "Item Swap", false);
		add("Player", "Swap2", false);
		add("Player", "Naruto Run", false);
		add("Player", "Config Profiles", false);
		// World
		add("World", "Fullbright", true);
		add("World", "Night Vision", true);
		add("World", "Custom World", false);
		add("World", "Sky Studio", false);
		add("World", "Sky Customization", false);
		// Movement
		add("Movement", "Auto Sprint", true);
		add("Movement", "Smart Sprint", true);
		add("Movement", "Auto Shift", false);
		load();
	}

	private ModuleManager() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("valerian.properties");
	}

	public static boolean isEnabled(String name) {
		return STATE.getOrDefault(name, false);
	}

	public static void toggle(String name) {
		STATE.put(name, !isEnabled(name));
		save();
	}

	public static List<Mod> forCategory(String category) {
		List<Mod> out = new ArrayList<>();
		for (Mod m : ALL) {
			if (m.category().equals(category)) out.add(m);
		}
		return out;
	}

	private static void load() {
		Path p = file();
		if (!Files.exists(p)) return;
		try (InputStream in = Files.newInputStream(p)) {
			Properties props = new Properties();
			props.load(in);
			for (String key : STATE.keySet()) {
				String v = props.getProperty(key);
				if (v != null) STATE.put(key, Boolean.parseBoolean(v));
			}
		} catch (IOException e) {
			ValerianClient.LOGGER.warn("Could not load config", e);
		}
	}

	private static void save() {
		Properties props = new Properties();
		for (Map.Entry<String, Boolean> e : STATE.entrySet()) {
			props.setProperty(e.getKey(), String.valueOf(e.getValue()));
		}
		try (OutputStream out = Files.newOutputStream(file())) {
			props.store(out, "Valerian Client modules");
		} catch (IOException e) {
			ValerianClient.LOGGER.warn("Could not save config", e);
		}
	}
}
