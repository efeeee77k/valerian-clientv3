package com.valerian;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
	public record Mod(String name, String category, boolean implemented, boolean defaultOn) {}

	/** Panels shown in the menu. HUDItem entries are sub-settings of the HUD module and have no panel. */
	public static final String[] CATEGORIES = {"Visual", "Player", "HUD"};
	public static final List<Mod> ALL = new ArrayList<>();
	private static final Map<String, Mod> BY_NAME = new HashMap<>();

	private static void add(String category, String name, boolean implemented, boolean defaultOn) {
		Mod m = new Mod(name, category, implemented, defaultOn);
		ALL.add(m);
		BY_NAME.put(name, m);
	}

	static {
		add("Visual", "Hitbox", true, false);
		add("Visual", "SwingSpeed", true, false);
		add("Visual", "SkinProtect", true, false);
		add("Player", "Sprint", true, false);
		add("Player", "NameProtect", true, false);
		add("Player", "ChatKeybind", true, true);
		add("Player", "Friends", true, true);
		add("HUD", "HUD", true, true);
		add("HUDItem", "FPS", true, true);
		add("HUDItem", "XYZ", true, true);
		add("HUDItem", "Ping", true, true);
		add("HUDItem", "Direction", true, true);
		add("HUDItem", "Armor", true, true);
		add("HUDItem", "Keystrokes", true, true);
		add("HUDItem", "Potion", true, true);
		add("HUDItem", "TargetHUD", true, true);
	}

	private ModuleManager() {}

	public static boolean isEnabled(String name) {
		Mod m = BY_NAME.get(name);
		return Config.getBool("mod." + name, m != null && m.defaultOn());
	}

	public static void toggle(String name) {
		Config.set("mod." + name, String.valueOf(!isEnabled(name)));
		Config.save();
	}

	public static List<Mod> forCategory(String category) {
		List<Mod> out = new ArrayList<>();
		for (Mod m : ALL) {
			if (m.category().equals(category)) out.add(m);
		}
		return out;
	}
}
