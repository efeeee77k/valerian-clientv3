package com.valerian;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public final class HudRenderer {
	private HudRenderer() {}

	public static void register() {
		HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
	}

	private static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden) return;

		if (ModuleManager.isEnabled("SVisuals HUD")) drawInfo(context, client);
		if (ModuleManager.isEnabled("Armor HP")) drawArmor(context, client);
		if (ModuleManager.isEnabled("Health Notify")) drawHealth(context, client);
		if (ModuleManager.isEnabled("Module List")) drawModuleList(context, client);
	}

	private static void drawInfo(DrawContext context, MinecraftClient client) {
		int ping = 0;
		if (client.getNetworkHandler() != null) {
			PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
			if (entry != null) ping = entry.getLatency();
		}
		String line1 = "Valerian | FPS: " + client.getCurrentFps() + " | Ping: " + ping + "ms";
		String line2 = String.format("XYZ: %.1f %.1f %.1f", client.player.getX(), client.player.getY(), client.player.getZ());
		int w = Math.max(client.textRenderer.getWidth(line1), client.textRenderer.getWidth(line2)) + 8;
		context.fill(4, 4, 4 + w, 30, 0x99101018);
		context.drawTextWithShadow(client.textRenderer, line1, 8, 8, 0xFFB388FF);
		context.drawTextWithShadow(client.textRenderer, line2, 8, 19, 0xFFFFFFFF);
	}

	private static void drawArmor(DrawContext context, MinecraftClient client) {
		EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
		String[] names = {"Helmet", "Chest", "Legs", "Boots"};
		int y = 40;
		for (int i = 0; i < slots.length; i++) {
			ItemStack stack = client.player.getEquippedStack(slots[i]);
			String text;
			int color = 0xFFFFFFFF;
			if (stack.isEmpty() || !stack.isDamageable()) {
				text = names[i] + ": -";
				color = 0xFF888888;
			} else {
				int max = stack.getMaxDamage();
				int left = max - stack.getDamage();
				int pct = Math.round(left * 100f / max);
				text = names[i] + ": " + pct + "%";
				color = pct > 50 ? 0xFF66FF66 : (pct > 20 ? 0xFFFFDD55 : 0xFFFF5555);
			}
			context.drawTextWithShadow(client.textRenderer, text, 8, y, color);
			y += 11;
		}
	}

	private static void drawHealth(DrawContext context, MinecraftClient client) {
		float hp = client.player.getHealth();
		if (hp > 6f || hp <= 0f) return;
		String text = "LOW HEALTH: " + Math.round(hp / 2f * 10f) / 10f + " hearts";
		int w = client.textRenderer.getWidth(text);
		int x = client.getWindow().getScaledWidth() / 2 - w / 2;
		int y = client.getWindow().getScaledHeight() / 2 + 30;
		context.drawTextWithShadow(client.textRenderer, text, x, y, 0xFFFF5555);
	}

	private static void drawModuleList(DrawContext context, MinecraftClient client) {
		int screenW = client.getWindow().getScaledWidth();
		int y = 4;
		int idx = 0;
		for (ModuleManager.Mod m : ModuleManager.ALL) {
			if (!m.implemented() || !ModuleManager.isEnabled(m.name())) continue;
			int w = client.textRenderer.getWidth(m.name());
			int g = Math.min(255, 140 + idx * 12);
			int color = 0xFF000000 | (0xB0 << 16) | (g << 8) | 0xFF;
			context.fill(screenW - w - 10, y - 1, screenW - 4, y + 10, 0x88101018);
			context.fill(screenW - 4, y - 1, screenW - 2, y + 10, color);
			context.drawTextWithShadow(client.textRenderer, m.name(), screenW - w - 7, y + 1, color);
			y += 12;
			idx++;
		}
	}
}
