package com.valerian;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

public class ValerianClientClient implements ClientModInitializer {
	private boolean wasDown = false;
	private boolean nightVisionApplied = false;

	@Override
	public void onInitializeClient() {
		ValerianClient.LOGGER.info("Valerian Client (client side) initialized!");
		HudRenderer.register();
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
	}

	private void onTick(MinecraftClient client) {
		handleMenuKey(client);
		ClientPlayerEntity p = client.player;
		if (p == null || client.world == null) return;
		handleSprint(client, p);
		handleNightVision(p);
	}

	private void handleMenuKey(MinecraftClient client) {
		if (client.getWindow() == null) return;
		boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
		if (down && !wasDown) {
			if (client.currentScreen instanceof ValerianScreen) {
				client.setScreen(null);
			} else if (client.currentScreen == null && client.world != null) {
				client.setScreen(new ValerianScreen());
			}
		}
		wasDown = down;
	}

	private void handleSprint(MinecraftClient client, ClientPlayerEntity p) {
		boolean smart = ModuleManager.isEnabled("Smart Sprint");
		if (ModuleManager.isEnabled("Auto Sprint")
			&& client.options.forwardKey.isPressed()
			&& !p.isSneaking()
			&& !p.horizontalCollision
			&& p.getHungerManager().getFoodLevel() > 6
			&& !(smart && p.isUsingItem())) {
			p.setSprinting(true);
		}
		if (smart && p.isUsingItem()) {
			p.setSprinting(false);
		}
	}

	private void handleNightVision(ClientPlayerEntity p) {
		boolean want = ModuleManager.isEnabled("Fullbright") || ModuleManager.isEnabled("Night Vision");
		if (want) {
			StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
			if (cur == null || cur.getDuration() < 240) {
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 500, 0, false, false, false));
			}
			nightVisionApplied = true;
		} else if (nightVisionApplied) {
			p.removeStatusEffect(StatusEffects.NIGHT_VISION);
			nightVisionApplied = false;
		}
	}
}
