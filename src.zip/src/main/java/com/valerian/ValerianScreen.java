package com.valerian;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ValerianScreen extends Screen {
	private static final int PER_PAGE = 12;
	private final String category;
	private final int page;

	public ValerianScreen() {
		this(ModuleManager.CATEGORIES[0], 0);
	}

	public ValerianScreen(String category, int page) {
		super(Text.literal("Valerian Client"));
		this.category = category;
		this.page = page;
	}

	private static Text label(ModuleManager.Mod m) {
		String state = ModuleManager.isEnabled(m.name()) ? "ON" : "OFF";
		return Text.literal(m.name() + (m.implemented() ? "" : " *") + ": " + state);
	}

	@Override
	protected void init() {
		int x0 = this.width / 2 - 210;
		int y0 = this.height / 2 - 100;

		for (int i = 0; i < ModuleManager.CATEGORIES.length; i++) {
			final String cat = ModuleManager.CATEGORIES[i];
			String text = cat.equals(category) ? "> " + cat : cat;
			addDrawableChild(ButtonWidget.builder(Text.literal(text), b ->
				MinecraftClient.getInstance().setScreen(new ValerianScreen(cat, 0))
			).dimensions(x0, y0 + i * 24, 80, 20).build());
		}

		List<ModuleManager.Mod> mods = ModuleManager.forCategory(category);
		int start = page * PER_PAGE;
		for (int i = 0; i < PER_PAGE && start + i < mods.size(); i++) {
			final ModuleManager.Mod m = mods.get(start + i);
			int bx = x0 + 95 + (i % 2) * 165;
			int by = y0 + (i / 2) * 24;
			addDrawableChild(ButtonWidget.builder(label(m), b -> {
				ModuleManager.toggle(m.name());
				b.setMessage(label(m));
			}).dimensions(bx, by, 160, 20).build());
		}

		int navY = y0 + 156;
		if (page > 0) {
			addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b ->
				MinecraftClient.getInstance().setScreen(new ValerianScreen(category, page - 1))
			).dimensions(x0 + 95, navY, 70, 20).build());
		}
		if (start + PER_PAGE < mods.size()) {
			addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b ->
				MinecraftClient.getInstance().setScreen(new ValerianScreen(category, page + 1))
			).dimensions(x0 + 185, navY, 70, 20).build());
		}
		addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b ->
			MinecraftClient.getInstance().setScreen(null)
		).dimensions(x0 + 275, navY, 80, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Valerian Client"),
			this.width / 2, this.height / 2 - 118, 0xFFB388FF);
		context.drawTextWithShadow(this.textRenderer, Text.literal("* = coming soon"),
			this.width / 2 - 210, this.height / 2 + 62, 0xFF888888);
	}
}
