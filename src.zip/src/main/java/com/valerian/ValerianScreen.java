package com.valerian;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Panel based menu. Drag a panel by its header, left click a module to toggle it,
 * right click a module to open or close its settings.
 */
public class ValerianScreen extends Screen {
	private interface Setting {
		String label();

		void left();

		void right();
	}

	private record RowRef(int panel, String module, Setting setting, int x, int y, int w, int h, boolean header) {
		boolean contains(int mx, int my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	private static final Set<String> EXPANDED = new HashSet<>();
	private static final int PW = 140;
	private static final int HEADER = 16;
	private static final int ROW = 14;
	private static final int SROW = 13;

	private boolean wasLeft = true;
	private boolean wasRight = true;
	private int dragging = -1;
	private int grabX = 0;
	private int grabY = 0;

	public ValerianScreen() {
		super(Text.literal("Valerian Client"));
	}

	private static String onOff(boolean on) {
		return on ? "ON" : "OFF";
	}

	private static Setting action(String label, Runnable r) {
		return new Setting() {
			public String label() {
				return label;
			}

			public void left() {
				r.run();
			}

			public void right() {
			}
		};
	}

	private static Setting toggleSetting(String label, String module) {
		return new Setting() {
			public String label() {
				return label + ": " + onOff(ModuleManager.isEnabled(module));
			}

			public void left() {
				ModuleManager.toggle(module);
			}

			public void right() {
				ModuleManager.toggle(module);
			}
		};
	}

	private static List<Setting> settings(String module) {
		List<Setting> l = new ArrayList<>();
		switch (module) {
			case "HUD" -> {
				for (HudRenderer.Element e : HudRenderer.ELEMENTS) {
					l.add(toggleSetting(e.name, e.name));
				}
				l.add(action("Edit positions >", () -> MinecraftClient.getInstance().setScreen(new HudEditScreen())));
			}
			case "SwingSpeed" -> l.add(new Setting() {
				public String label() {
					return "Slowdown: " + Math.max(1, Math.min(3, Config.getInt("swing.level", 3))) + "/3";
				}

				public void left() {
					int v = Math.max(1, Math.min(3, Config.getInt("swing.level", 3)));
					Config.set("swing.level", String.valueOf(v >= 3 ? 1 : v + 1));
					Config.save();
				}

				public void right() {
					int v = Math.max(1, Math.min(3, Config.getInt("swing.level", 3)));
					Config.set("swing.level", String.valueOf(v <= 1 ? 3 : v - 1));
					Config.save();
				}
			});
			case "ChatKeybind" -> l.add(action("Edit binds >", () -> MinecraftClient.getInstance().setScreen(new ChatBindsScreen(-1))));
			case "Friends" -> l.add(action("Manage friends >", () -> MinecraftClient.getInstance().setScreen(new FriendsScreen())));
			case "NameProtect" -> {
				final String own = NameProtect.ownFake();
				final String oth = NameProtect.othersFake();
				l.add(action("Your name: " + own + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Your fake name", own, NameProtect::setOwn))));
				l.add(action("Others: " + (oth.isEmpty() ? "OFF" : oth) + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Name for other players (empty = off)", oth, NameProtect::setOthers))));
			}
			case "SkinProtect" -> {
				final String acc = SkinManager.account();
				l.add(action("Account: " + (acc.isEmpty() ? "none" : acc) + " >", () ->
					MinecraftClient.getInstance().setScreen(new TextInputScreen("Premium account name", acc, SkinManager::setAccount))));
				l.add(action("Reload skin", SkinManager::reload));
				l.add(action(SkinManager.status(), () -> { }));
			}
			default -> { }
		}
		return l;
	}

	private int panelX(int idx) {
		return Config.getInt("panel." + ModuleManager.CATEGORIES[idx] + ".x", 10 + idx * (PW + 10));
	}

	private int panelY(int idx) {
		return Config.getInt("panel." + ModuleManager.CATEGORIES[idx] + ".y", 24);
	}

	private void setPanelPos(int idx, int x, int y) {
		Config.set("panel." + ModuleManager.CATEGORIES[idx] + ".x", String.valueOf(x));
		Config.set("panel." + ModuleManager.CATEGORIES[idx] + ".y", String.valueOf(y));
	}

	private List<RowRef> rows(int idx) {
		String panel = ModuleManager.CATEGORIES[idx];
		int x = panelX(idx);
		int y = panelY(idx);
		List<RowRef> out = new ArrayList<>();
		out.add(new RowRef(idx, null, null, x, y, PW, HEADER, true));
		int cy = y + HEADER;
		for (ModuleManager.Mod m : ModuleManager.forCategory(panel)) {
			out.add(new RowRef(idx, m.name(), null, x, cy, PW, ROW, false));
			cy += ROW;
			if (EXPANDED.contains(m.name())) {
				for (Setting s : settings(m.name())) {
					out.add(new RowRef(idx, m.name(), s, x, cy, PW, SROW, false));
					cy += SROW;
				}
			}
		}
		return out;
	}

	@Override
	public void render(DrawContext c, int mx, int my, float delta) {
		super.render(c, mx, my, delta);
		MinecraftClient mc = MinecraftClient.getInstance();
		long handle = mc.getWindow().getHandle();
		boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
		boolean leftClick = left && !wasLeft;
		boolean rightClick = right && !wasRight;
		wasLeft = left;
		wasRight = right;

		// dragging a panel
		if (dragging >= 0) {
			if (left) {
				int nx = Math.max(0, Math.min(this.width - PW, mx - grabX));
				int ny = Math.max(0, Math.min(this.height - HEADER, my - grabY));
				setPanelPos(dragging, nx, ny);
			} else {
				Config.save();
				dragging = -1;
			}
		}

		// click handling, top most panel (last drawn) first
		if ((leftClick || rightClick) && dragging < 0) {
			boolean consumed = false;
			for (int idx = ModuleManager.CATEGORIES.length - 1; idx >= 0 && !consumed; idx--) {
				for (RowRef r : rows(idx)) {
					if (!r.contains(mx, my)) continue;
					consumed = true;
					if (r.header()) {
						if (leftClick) {
							dragging = idx;
							grabX = mx - r.x();
							grabY = my - r.y();
						}
					} else if (r.setting() == null) {
						if (leftClick) {
							ModuleManager.toggle(r.module());
						} else if (!settings(r.module()).isEmpty()) {
							if (!EXPANDED.remove(r.module())) EXPANDED.add(r.module());
						}
					} else {
						if (leftClick) {
							r.setting().left();
						} else {
							r.setting().right();
						}
						if (mc.currentScreen != this) return;
					}
					break;
				}
			}
		}

		// drawing
		for (int idx = 0; idx < ModuleManager.CATEGORIES.length; idx++) {
			for (RowRef r : rows(idx)) {
				boolean hover = r.contains(mx, my);
				if (r.header()) {
					c.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), 0xFF2B1F55);
					String title = ModuleManager.CATEGORIES[idx];
					int tw = mc.textRenderer.getWidth(title);
					c.drawTextWithShadow(mc.textRenderer, title, r.x() + (r.w() - tw) / 2, r.y() + 4, 0xFFD6C2FF);
				} else if (r.setting() == null) {
					boolean on = ModuleManager.isEnabled(r.module());
					int bg = on ? (hover ? 0xEE7552E0 : 0xEE5B3FC4) : (hover ? 0xEE222234 : 0xEE14141E);
					c.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), bg);
					ModuleManager.Mod mod = null;
					for (ModuleManager.Mod m : ModuleManager.ALL) {
						if (m.name().equals(r.module())) mod = m;
					}
					String name = r.module() + (mod != null && !mod.implemented() ? " *" : "");
					c.drawTextWithShadow(mc.textRenderer, name, r.x() + 5, r.y() + 3, 0xFFFFFFFF);
					if (!settings(r.module()).isEmpty()) {
						String sign = EXPANDED.contains(r.module()) ? "-" : "+";
						c.drawTextWithShadow(mc.textRenderer, sign, r.x() + r.w() - 10, r.y() + 3, 0xFFD6C2FF);
					}
				} else {
					c.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), hover ? 0xEE1C1C2A : 0xEE0C0C14);
					c.fill(r.x(), r.y(), r.x() + 2, r.y() + r.h(), 0xFF5B3FC4);
					c.drawTextWithShadow(mc.textRenderer, mc.textRenderer.trimToWidth(r.setting().label(), r.w() - 12), r.x() + 8, r.y() + 3, 0xFFCCCCCC);
				}
			}
		}

		String hint = "Left click: on/off   Right click: settings   Drag the title to move";
		int hw = mc.textRenderer.getWidth(hint);
		c.drawTextWithShadow(mc.textRenderer, hint, (this.width - hw) / 2, this.height - 12, 0xFF888888);
	}
}
