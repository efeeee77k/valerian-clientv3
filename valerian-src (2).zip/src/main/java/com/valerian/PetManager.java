package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.AxolotlEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.passive.FoxEntity;
import net.minecraft.entity.passive.ParrotEntity;
import net.minecraft.entity.passive.WolfEntity;

/** A client side pet that follows you. Only you can see it. */
public final class PetManager {
	public static final String[] TYPES = {"None", "Parrot", "Fox", "Bee", "Wolf", "Axolotl"};

	private static Entity pet = null;
	private static String petType = "";
	private static ClientWorld petWorld = null;
	private static int tickCount = 0;

	private PetManager() {}

	public static String selected() {
		String s = Config.get("pet.type", "None");
		for (String t : TYPES) {
			if (t.equals(s)) return s;
		}
		return "None";
	}

	public static void cycle(int dir) {
		int idx = 0;
		String cur = selected();
		for (int i = 0; i < TYPES.length; i++) {
			if (TYPES[i].equals(cur)) idx = i;
		}
		idx = (idx + dir + TYPES.length) % TYPES.length;
		Config.set("pet.type", TYPES[idx]);
		Config.save();
	}

	private static void remove() {
		if (pet != null) {
			pet.discard();
			pet = null;
		}
		petType = "";
		petWorld = null;
	}

	public static void tick(MinecraftClient mc) {
		String want = ModuleManager.isEnabled("Pets") ? selected() : "None";
		if (mc.player == null || mc.world == null || want.equals("None")) {
			remove();
			return;
		}
		if (pet == null || !want.equals(petType) || petWorld != mc.world || pet.isRemoved()) {
			remove();
			spawn(mc, want);
		}
		if (pet != null) follow(mc.player);
	}

	private static void spawn(MinecraftClient mc, String type) {
		ClientWorld world = mc.world;
		Entity e = switch (type) {
			case "Parrot" -> new ParrotEntity(EntityType.PARROT, world);
			case "Fox" -> new FoxEntity(EntityType.FOX, world);
			case "Bee" -> new BeeEntity(EntityType.BEE, world);
			case "Wolf" -> new WolfEntity(EntityType.WOLF, world);
			case "Axolotl" -> new AxolotlEntity(EntityType.AXOLOTL, world);
			default -> null;
		};
		if (e == null) return;
		e.setId(-777000 - type.length());
		e.setNoGravity(true);
		e.noClip = true;
		e.setPosition(mc.player.getX(), mc.player.getY(), mc.player.getZ());
		world.addEntity(e);
		pet = e;
		petType = type;
		petWorld = world;
	}

	private static void follow(ClientPlayerEntity p) {
		boolean flying = petType.equals("Parrot") || petType.equals("Bee");
		double yaw = Math.toRadians(p.getYaw());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double rx = -Math.cos(yaw);
		double rz = -Math.sin(yaw);
		double tx = p.getX() + rx * 0.9 - fx * 0.9;
		double tz = p.getZ() + rz * 0.9 - fz * 0.9;
		double ty = p.getY() + (flying ? 1.5 + Math.sin(tickCount * 0.12) * 0.15 : 0.0);
		tickCount++;

		double dx = tx - pet.getX();
		double dy = ty - pet.getY();
		double dz = tz - pet.getZ();
		if (dx * dx + dy * dy + dz * dz > 36.0) {
			pet.setPosition(tx, ty, tz);
		} else {
			pet.setPosition(pet.getX() + dx * 0.2, pet.getY() + dy * 0.2, pet.getZ() + dz * 0.2);
		}
		pet.setOnGround(!flying);
		float targetYaw = p.getYaw();
		pet.setYaw(targetYaw);
		pet.setPitch(0f);
		if (pet instanceof net.minecraft.entity.LivingEntity le) {
			le.setBodyYaw(targetYaw);
			le.setHeadYaw(targetYaw);
		}
	}
}
