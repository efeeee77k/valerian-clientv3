package com.valerian;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.entity.EntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import org.lwjgl.glfw.GLFW;

public class ValerianClientClient implements ClientModInitializer {
	private boolean menuKeyWasDown = false;
	private boolean openRequested = false;
	private boolean skinInitDone = false;
	private int tickCounter = 0;
	private final boolean[] bindWasDown = new boolean[ChatBinds.SLOTS];

	@Override
	public void onInitializeClient() {
		ValerianClient.LOGGER.info("Valerian Client (client side) initialized!");
		HudRenderer.register();
		LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
			if (entityType == EntityType.PLAYER) {
				@SuppressWarnings({"unchecked", "rawtypes"})
				FeatureRendererContext raw = (FeatureRendererContext) entityRenderer;
				@SuppressWarnings("unchecked")
				CosmeticsFeatureRenderer feature = new CosmeticsFeatureRenderer(raw);
				registrationHelper.register(feature);
			}
		});
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(ClientCommandManager.literal("valerian").executes(ctx -> {
				openRequested = true;
				return 1;
			}))
		);
		ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> NameProtect.apply(message));
	}

	private void onTick(MinecraftClient client) {
		if (client.getWindow() == null) return;
		handleMenu(client);
		PetManager.tick(client);
		ClientPlayerEntity p = client.player;
		if (p == null || client.world == null) return;
		if (!skinInitDone) {
			skinInitDone = true;
			SkinManager.init();
		}
		if (tickCounter++ % 20 == 0) NameProtect.refresh(client);
		handleSprint(client, p);
		handleSwing(p);
		handleChatBinds(client);
	}

	private void handleMenu(MinecraftClient client) {
		boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
		if (down && !menuKeyWasDown) {
			if (client.currentScreen instanceof ValerianScreen) {
				client.setScreen(null);
			} else if (client.currentScreen == null && client.world != null) {
				client.setScreen(new ValerianScreen());
			}
		}
		menuKeyWasDown = down;
		if (openRequested && client.currentScreen == null && client.world != null) {
			openRequested = false;
			client.setScreen(new ValerianScreen());
		}
	}

	private void handleSprint(MinecraftClient client, ClientPlayerEntity p) {
		if (ModuleManager.isEnabled("Sprint")
			&& client.options.forwardKey.isPressed()
			&& !p.isSneaking()
			&& !p.horizontalCollision
			&& p.getHungerManager().getFoodLevel() > 6) {
			p.setSprinting(true);
		}
	}

	private void handleSwing(ClientPlayerEntity p) {
		if (!ModuleManager.isEnabled("SwingSpeed")) return;
		int level = Math.max(1, Math.min(3, Config.getInt("swing.level", 3)));
		int period = 5 - level;
		if (p.handSwinging && p.handSwingTicks > 0 && p.age % period == 0) {
			p.handSwingTicks--;
		}
	}

	private void handleChatBinds(MinecraftClient client) {
		if (!ModuleManager.isEnabled("ChatKeybind")) return;
		long handle = client.getWindow().getHandle();
		for (int i = 0; i < ChatBinds.SLOTS; i++) {
			int key = ChatBinds.getKey(i);
			if (key == 0) {
				bindWasDown[i] = false;
				continue;
			}
			boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
			if (down && !bindWasDown[i] && client.currentScreen == null) {
				String msg = ChatBinds.getMsg(i).trim();
				ClientPlayNetworkHandler nh = client.getNetworkHandler();
				if (!msg.isEmpty() && nh != null) {
					if (msg.startsWith("/")) {
						nh.sendChatCommand(msg.substring(1));
					} else {
						nh.sendChatMessage(msg);
					}
				}
			}
			bindWasDown[i] = down;
		}
	}
}
