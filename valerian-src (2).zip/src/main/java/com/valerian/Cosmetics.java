package com.valerian;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Identifier;

public final class Cosmetics {
	public enum Slot {
		HEAD, BACK
	}

	public record Item(String id, String name, Slot slot) {}

	public static final List<Item> ALL = List.of(
		new Item("crown", "Crown", Slot.HEAD),
		new Item("straw_hat", "Straw Hat", Slot.HEAD),
		new Item("devil_horns", "Devil Horns", Slot.HEAD),
		new Item("demon_wings", "Demon Wings", Slot.BACK),
		new Item("angel_wings", "Angel Wings", Slot.BACK)
	);

	private Cosmetics() {}

	private static String key(Slot slot) {
		return "cosmetic." + slot.name().toLowerCase();
	}

	public static String equipped(Slot slot) {
		return Config.get(key(slot), "none");
	}

	public static void equip(Slot slot, String id) {
		Config.set(key(slot), id);
		Config.save();
	}

	public static List<Item> forSlot(Slot slot) {
		List<Item> out = new ArrayList<>();
		for (Item i : ALL) {
			if (i.slot() == slot) out.add(i);
		}
		return out;
	}

	public static Identifier texture(String id) {
		return Identifier.of("valerian", "textures/entity/cosmetics/" + id + ".png");
	}
}
