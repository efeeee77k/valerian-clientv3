package com.valerian;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;

/** Draws the cosmetics you picked on your own player model (also in the menu preview). */
public class CosmeticsFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	public CosmeticsFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state, float limbAngle, float limbDistance) {
		if (!ModuleManager.isEnabled("Cosmetics")) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || state.id != mc.player.getId()) return;
		draw(Cosmetics.Slot.HEAD, matrices, queue, light, state);
		draw(Cosmetics.Slot.BACK, matrices, queue, light, state);
	}

	private void draw(Cosmetics.Slot slot, MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state) {
		String id = Cosmetics.equipped(slot);
		if (id.equals("none")) return;
		ModelPart part = CosmeticModels.get(id);
		if (part == null) return;
		if (slot == Cosmetics.Slot.HEAD) {
			part.yaw = state.relativeHeadYaw * 0.017453292f;
			part.pitch = state.pitch * 0.017453292f;
		}
		CosmeticModels.animate(id, part);
		RenderLayer layer = RenderLayer.getEntityCutoutNoCull(Cosmetics.texture(id));
		queue.submitModelPart(part, matrices, layer, light, OverlayTexture.DEFAULT_UV, null);
	}
}
